var path = require('path');
var webpackConfig = require('./webpack.test.config')

module.exports = function(config) {
  config.set({
    basePath: '',
    frameworks: [
        'mocha', 
        'chai'
    ],
    files: [
        'app/**/*.test.js'
    ],
    webpack: webpackConfig,
    preprocessors: {
        'app/**/*.test.js': ['webpack','sourcemap']
    },
    reporters: [
        'progress', 
        'coverage',
        'dots'
    ],
    browsers: [
        'Chrome'
    ],
    plugins: [
      'karma-chrome-launcher',
      'karma-chai',
      'karma-mocha',
      'karma-sourcemap-loader',
      'karma-webpack',
      'karma-coverage'
    ]
  })
}
