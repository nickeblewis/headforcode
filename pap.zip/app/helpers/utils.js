export const curry = (fn, args = []) =>
  (...a) => {
    let x = args.concat(a);
    return x.length >= fn.length ?
      fn(...x) :
      curry(fn, x);
  };

export const curryN = (fn, count, args = []) =>
  (...a) => {
    let x = args.concat(a);
    return x.length > count ?
      fn(...x) :
      curryN(fn, count, x);
  };

export const memoize = (fn) => {
  const cache = new Map();
  const memo = (...a) => {
    let key = a.reduce((hash, val) =>
      hash += val === Object(val) ?
        JSON.stringify(val) :
        val, '');
    if (!cache.has(key)) cache.set(key, fn(...a));
    return cache.get(key);
  };
  return Object.defineProperties(memo, {
    _cache: { value: () => cache }
  });
};

export const inherit = (stream, obj) => {
  const proto = Object.create(Reflect.getPrototypeOf(stream));
  for (let fn in proto) {
    obj[fn] = typeof proto[fn] === 'function' ? proto[fn].bind(stream) : proto[fn];
  }
  return obj;
};

/* eslint-disable no-console */
export const log = console.log.bind(console);
export const info = console.info.bind(console);
export const warn = console.warn.bind(console);
export const error = console.error.bind(console);
export const time = (console.time ? console.time : console.log).bind(console);
export const timeEnd = (console.timeEnd ? console.timeEnd : console.log).bind(console);
/* eslint-enable no-console */

export const act = curry((fn, x) => (fn(x), x));
export const map = curry((fn, x) => x.map(fn));
export const filter = curry((fn, x) => x.filter(fn));
export const filterNot = curry((fn, x) => x.filter(y => !fn(y)));

export const find = curry((fn, x) => x.find(fn));
export const findIndex = curry((fn, x) => x.findIndex(fn));

export const get = curry((x, o) => o[x]);
export const set = curry((x, o) => ({ [x]: o }));

export const take = curry((x, a) => a.slice(0, x));

export const join = curry((what, x) => x.join(what));

export const noop = () => {};

export const filterSplit = (...a) =>
  x => a.reduce((acc, fn) =>
    acc.push(fn(x)) && acc, []);

export const over = filterSplit;

export const into = curry((y, fn, x) => x.reduce(fn, y));
export const reduce = curry((fn, y, x) => x.reduce(fn, y));

export const concat = curry((y, x) => x.concat(y));
export const split = curry((by, x) => x.split(by));
export const spread = curry((fn, x) => fn(...x));
export const sort = curry((fn, x) => [ ...x ].sort(fn));
export const uniq = x => [ ...new Set(x) ];

/**
 * @function identity :: a -> a
 * @description Returns the parameter supplied
 * @param {*} x The value to return.
 * @return {*} The value, `x`.
 *
 * @example
 * ```js
 * identity(1) // 1
 *
 * const obj = {}
 * identity(obj) === obj; // true
 * ```
 */
export const identity = x => x;

/**
 * @function head :: [a] -> a | Undefined
 * @description Returns the first element of the given list
 * @param {String | Array} list
 * @return {*}
 *
 * @example
 * ```js
 * head([1, 2, 3]) // 1
 * ```
 */
export const head = x => x[0];

/**
 * @function last :: [a] -> a | Undefined
 * @description Returns the last element of the given list
 * @param {String | Array} list
 * @return {*}
 *
 * @example
 * ```js
 * head([1, 2, 3]) // 3
 * ```
 */
export const last = x => x[x.length - 1];

export const tail = x => x.slice(1);

export const toArray = x => Array.isArray(x) ? x : [ x ];

/**
 * @function debounce
 * @description Fires a function 100ms after an event has stopped happening, eg after a user has stopped scrolling
 * @description Scroll -> Scroll -> Scroll -> Scroll -> User stops scroll -> 100ms - > *POP*
 * @param fn delay
 *
 * @example
 * ```js
 * const callback = debounce(function() {
 *   console.log('debounce!');
 * }, 100);
 * window.addEventListener('scroll', callback);
 * window.removeEventListener('scroll', callback);
 * ```
 */
export const debounce = (fn, delay = 100, timer) => () => {
  clearTimeout(timer);
  timer = setTimeout(fn, delay);
};

/**
 * @function throttle
 * @description Fires a function every 50ms whilst an event is happening, eg a user is scrolling
 * @description Scroll -> Scroll -> *POP* -> Scroll -> Scroll -> *POP* -> Scroll -> Scroll -> *POP -> User stops scroll
 * @param fn delay
 *
 * @example
 * ```js
 * const callback = throttle(function() {
 *   console.log('throttle!');
 * }, 100);
 * window.addEventListener('scroll', callback);
 * window.removeEventListener('scroll', callback);
 * ```
 */
export const throttle = (fn, delay = 50, timer) => () => {
  if (timer) return false;
  timer = setTimeout(() => {
    timer = null;
    fn();
  }, delay);
};

export const defer = (fn, ...args) => setTimeout((...x) => fn(...x), 1, ...args);
export const safe = (fn, or = undefined) => {
  try { return fn(); }
  catch (e) { return or; }
};


/**
 * @function omit :: [String] -> {String: *} -> {String: *}
 * @description Returns a partial copy of an object omitting the keys specified.
 * @param {String | Array<String>} keys a String or an array of String `keys` to omit
 * @param {Object} obj The object to omit from
 * @return {Object} A new object without properties from `keys`.
 *
 * @example
 * ```js
 * omit(['a'], {a: 1, b: 2, c: 3}); // {b: 2, c: 3}
 * ```
 */
export const omit = curry((props, x) => {
  const ps = toArray(props);
  return pluck(Object.keys(x).filter(k =>
    typeof ps.find(p => p === k) === 'undefined'), x);
});

/**
 * @function pluck :: [String] -> {String: *} -> {String: *}
 * @description Returns a partial copy of an object picking the keys specified.
 * @param {String | Array<String>} keys String or an array of String `keys` to pick
 * @param {Object} obj The object to pick from
 * @return {Object} A new object with properties from `keys`.
 *
 * @example
 * ```js
 * pluck(['a'], {a: 1, b: 2, c: 3}); // {a: 1}
 * ```
 */
export const pluck = curry((props, x) => {
  return toArray(props).reduce((acc, prop) => {
    if (typeof x[prop] !== 'undefined') acc[prop] = x[prop];
    return acc;
  }, {});
});

/**
 * @function pluckIn
 * @description Returns a partial copy of an object, recursively picking the key specified.
 * @param {String} key String key to pick
 * @param {Object} obj The object to pick from
 * @return {Object} A new object with properties of `key`.
 *
 * @example
 * ```js
 * pluckIn('myKey', myObj)
 * ```
 */
export const pluckIn = (key, obj) => {
  return Object.entries(obj).reduce((acc, [ k, v ]) => {
    if (isObject(v)) {
      acc[k] = pluckIn(key, v);
      if (!Object.keys(acc[k]).length) delete acc[k]; // avoid returning empty objects
    } else if (k === key) {
      acc[k] = v;
    }
    return acc;
  }, {});
};

export const isObject = o => typeof o === 'object';
export const isFunction = o => typeof o === 'function';
export const isNull = o => o === null;
export const isUndefined = o => typeof o === 'undefined';

export const isPrimitive = o => {
  const type = typeof o;
  return o == null || (type !== 'object' && type !== 'function');
};

export const isPlainObject = o => {
  const isObjectObject = o =>
    o != null && isObject(o) && !Array.isArray(o);

  if (isObjectObject(o) === false) return false;
  if (typeof o.constructor !== 'function') return false;
  if (isObjectObject(o.constructor.prototype) === false) return false;
  if (o.constructor.prototype.hasOwnProperty('isPrototypeOf') === false) return false;
  return true;
};

export const stateExtend = (state, newState) => {
  const stateKeys = uniq(concat(Object.keys(state), Object.keys(newState)));
  return stateKeys.reduce((acc, k) => {
    acc[k] = newState[k] ?
      (isObject(newState[k]) ? { ...state[k], ...newState[k] } : newState[k]) :
      state[k];
    return acc;
  }, {});
};

export const isUuid = (str) => {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(str);
};

/**
 * @function compose :: ((y -> z), (x -> y), ..., (o -> p), ((a, b, ..., n) -> o)) -> ((a, b, ..., n) -> z)
 * @description Right-to-left function composition.
 * @param {...Function} functions
 * @return {Function}
 *
 * @example
 * ```js
 * let fn = compose(head, tail)
 * fn([['baz'], ['foo', 'bar']]) // 'foo'
 * ```
 */
export const compose = (...a) => a.reduce((f, g) => (...x) => f(g(...x)));
export const flatten = a => a.reduce((acc, x) =>
  Array.isArray(x) ? acc.concat(flatten(x)) :
  acc.concat(x), []);

export const concatAll = a => a.reduce((acc, x) => acc.concat(x), []);

/**
 * @function format :: (String -> Object) -> String
 * @description Format a given string to include key/value pairs from a dictionary
 * @param {String} str - the string to format
 * @param {Object} dict - dictionary key/value pairs to be used with the string
 * @returns {String} - the formatted string
 *
 * @example
 * ```js
 * format('Hello, ${name}', { name: 'Joe' }) // 'Hello, Joe'
 * format('Hello, ${name}')({ name: 'Joe' }) // 'Hello, Joe'
 * ```
 */
export const format = curry((str, dict) => str.toString().replace(/[\$|\?]{([^}]+)}/g, (m, k) => dict[k]));

const s4 = () => Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);

export const uuid = () => {
  const p4 = '4' + s4().slice(-3);
  const p5 = ((parseInt(s4().slice(0, 1), 16) & 3) | 8).toString(16) + s4().slice(-3);
  return `${s4()}${s4()}-${s4()}-${p4}-${p5}-${s4()}${s4()}${s4()}`;
};

/**
 * @function getOrigin
 * @description get the location host.
 * @returns {String} url - the current origin url or an empty string
 */
export const getOrigin = () =>
  safe(() => window.location.origin ? window.location.origin :
    // Fix IE 10 window.location.origin issue
    window.location.protocol + '//' + window.location.host
);

/**
 * @function getCurrentRoute
 * @description get the location pathname and hash combined.
 * @returns {String} url - the current path url or an empty string
 */
export const getCurrentRoute = () =>
  safe(() => window.location.pathname + window.location.hash);


/**
 * @private
 * @function filterObjectsToKV
 * @description Converts all objects in an array to an array of key-value pairs, point-free.
 * @param {Array} input - an array of values
 * @returns {Array} - an array of key/value pairs
 */
const filterObjectsToKV = compose(concatAll, map(Object.entries), filter(isObject));

/**
 * @private
 * @function filterKeysToKV
 * @description Converts all non-objects in an array to an array of key-mirror pairs, point-free.
 * @param {Array} input - an array of values
 * @returns {Array} - an array of key/mirror pairs
 */
const filterKeysToKV = compose(map(k => [ k, k ]), filterNot(isObject));

/**
 * @private
 * @function undefinedToFalse
 * @description Converts all undefined values in key/value pairs into key-false, point-free.
 * @param {Array} input - a key/value pair
 * @returns {Array} - a key-false pair
 */
const undefinedToFalse = ([ k, v ]) => [ k, typeof v === 'undefined' ? false : v ];

/**
 * @function argsToKV
 * @description Converts all arguments into an array of key/value pairs, point-free.
 * @param {Array} input - an array of arguments
 * @returns {Array} - an array of key/value pairs
 */
export const argsToKV = compose(concatAll, filterSplit(filterObjectsToKV, filterKeysToKV), flatten);

/**
 * @function undefinedToMirror
 * @description Converts all undefined values in key/value pairs into key-mirrors, point-free.
 * @param {Array} input - a key/value pair
 * @returns {Array} - a key-mirror pair
 */
export const undefinedToMirror = ([ k, v ]) => [ k, typeof v === 'undefined' ? k : v ];

/**
 * @function classSet
 * @description Converts arguments into a html class, so `classSet('date', { enabled: true })` will equal `date`
 * @param {args} - Arguments can include strings, objects and arrays
 * @returns {String} - an array of key/value pairs
 */
export const classSet = (...args) => compose(
  join(' '),
  map(([ k, v ]) => k),
  filter(([ k, v ]) => v),
  map(undefinedToFalse),
  argsToKV
)(args);

const markdownRegexes = {
  break: {
    re: /\n/,
    map: m => ({ value: '' })
  },
  strong: {
    re: /\_([^\_]+)\_/,
    map: m => ({ value: m[m.length - 1] })
  },
  em: {
    re: /\*([^\*]+)\*/,
    map: m => ({ value: m[m.length - 1] })
  },
  link: {
    re: /(\>)?\[([^\]]+)\]\(([^\)]+)\)/,
    map: m => ({ href: m[m.length - 1], internal: !!m[1], value: m[2] })
  }
};

export const tokenize = (input, regexes = markdownRegexes) => {
  const testRules = (substr) =>
    Object.values(regexes).some(({ re }) =>
      re.test(substr));

  const getRule = (substr) =>
    Object.entries(regexes).find(([ key, { re } ]) =>
      re.test(substr));

  const output = [];

  const parse = str => {
    const index = Array.from({ ...String(str), length: str.length + 1 })
      .findIndex((_, i) => testRules(str.substr(0, i)));

    if (index > -1) {
      const substr = str.substr(0, index);
      const [ type, { re, map } ] = getRule(substr);
      const start = substr.search(re);
      const match = substr.match(re);
      if (start !== 0) {
        output.push({ type: 'block', value: substr.substr(0, start) });
      }
      output.push({ type, ...map(match) });
      if (index === str.length) return output;
      else return parse(str.slice(index));
    } else {
      output.push({ type: 'block', value: str });
      return output;
    }
  };

  return parse(input);
};

/**
 * @function indexBy
 * @description Given an `arr` of objects, indexes the objects by a specified `key`
 * @param {Array} arr - Array of objects to be indexed
 * @param {String} key - The key from each object to index by
 * @returns {Object} - Object containing each `arr` item, indexed by `key`
 */
export const indexBy = (arr, key) =>
  arr.reduce((acc, obj) => {
    acc[obj[key]] = obj;
    return acc;
  }, {});

/**
 * @function sortBy
 * @description Given an `arr` of objects, sorts it by the number value of a specified `key`
 * @param {Array} arr - Array of objects to be sorted
 * @param {String} key - The key from each object to sort by - it's value should be a number
 * @param {Array} [order = 'asc'] - The order to sort in - where 'asc' will put the lowest value first, and 'desc' the highest value first
 * @returns {Array} - Array containing each `arr` item, sorted by the value of `key`
 */
export const sortBy = (arr, key, order = 'asc') =>
  arr.sort((a, b) => a[key] > b[key] ?
    (order === 'desc' ? -1 : 1) :
    (order === 'desc' ? 1 : -1)
  );

export const todaysTimestamp = () =>
  new Date(Date.UTC(new Date().getFullYear(), new Date().getMonth(), new Date().getDate())).getTime();

export const getViewDimensions = (win = window, doc = document) => ({
  screenW: win.screen.availWidth,
  screenH: win.screen.availHeight,
  scrollY: win.pageYOffset,
  viewportW: doc.documentElement.clientWidth,
  viewportH: doc.documentElement.clientHeight,
  documentH: Math.max(doc.documentElement.offsetHeight, doc.documentElement.scrollHeight) // scrollHeight for IE
  // the following props are not used anywhere yet - uncomment when required!
  // browserW: win.outerWidth,
  // browserH: win.outerHeight
});
