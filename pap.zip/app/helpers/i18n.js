import { format, safe } from 'helpers/utils';

/**
 * @function i18nSetup:: x -> y -> (a -> b -> c ->)
 * @description Setup i18n with scope of external variables.
 * @param {String} separator - a custom fallback string
 * @param {String} warning - dictionary key/value pairs to be used with the string
 * @returns {Function} i18n
 */
export const i18nSetup = (separator, warning, loc) => (key, fallback, dict) => {
  const locale = loc || safe(() => window._locale || {}, {});

  const nested = (...keys) => safe(() => keys.reduce((acc, k) => acc[k], locale));

  const content = (key.indexOf(separator) > 0 ? nested(...key.split(separator)) :
    locale[key]) || fallback || `${warning} ${key}`;

  if (typeof fallback === 'object') dict = fallback;

  return typeof content === 'string' && /\${([^}]+)}/.test(content) ?
    (dict ? format(content, dict) : format(content)) : content;

  // Test i18n keys

  // return typeof content === 'string' && /\${([^}]+)}/.test(content) ?
  //   (dict ? key : _ => key) : key;

};

/**
 * @function i18n
 * @description Given a key, retrieve content from language data
 * @param {String} key - the content key to look for in the language data
 * @param {String} [fallback] - a custom fallback string
 * @param {Object} [value] - dictionary key/value pairs to be used with the string
 * @returns {Function|String|Object} -
 * the format util function is returned if interpolator delimiters are found in the key value,
 * otherwise the value of the key is returned,
 * which is either a content string, or an object containing child content strings
 *
 * @example
 * ```js
 * i18n('shared:currency:gbp') // returns '£';
 * i18n('shared') // returns shared object;
 * i18n('shared:typo') // returns 'shared:typo';
 * i18n('shared:typo', 'Oops') // returns 'Oops';
 * i18n('formatExample', { a: 'world' }) // assuming the value of 'formatExample' was 'Hello $[a}!', returns 'Hello world!'
 * i18n('formatExample')({ a: 'world' }) // assuming the value of 'formatExample' was 'Hello $[a}!', returns 'Hello world!'
 * ```
 */
export const i18n = i18nSetup(':', 'Missing value for key:');
