import React from 'react';
import { i18n } from 'helpers/i18n';
import { Fade , Panel, Grid, Row, Col, Image, Thumbnail, ButtonGroup, Button, Well } from 'react-bootstrap';
import { SliderPicker } from 'react-color';
import Dropzone from 'react-dropzone';
import request from 'superagent';

/* In the absence of an official PCL back-end for image handling, 
   I have created a Cloudinary (free) account to be able to test this functionality out 
   */
const CLOUDINARY_UPLOAD_PRESET = 'gec3tjz3';
const CLOUDINARY_UPLOAD_URL = 'https://api.cloudinary.com/v1_1/dqpknoetx/upload';

class Branding extends React.Component {

    constructor(props) {
        super(props);
        this.onColourChange = this.onColourChange.bind(this);

        this.state = {
            open: true,
            uploadedFile: null,
            uploadedFileCloudinaryUrl: '',
            brandColour: '#ffffff'
        };
    }

    onColourChange(event) {
        this.setState({ 
            brandColour: event.hex 
        });

        this.props.onSelect(this.state.brandColour);
    }

    onImageDrop(files) {
        this.setState({
            uploadedFile: files[0]
        });

        this.handleImageUpload(files[0]);
    }

    handleImageUpload(file) {
        let upload = request.post(
            CLOUDINARY_UPLOAD_URL).field('upload_preset', 
            CLOUDINARY_UPLOAD_PRESET).field('file', file);

        upload.end((err, response) => {
            if (err) {
                console.error(err);
            }

            if (response.body.secure_url !== '') {
                this.setState({
                    uploadedFileCloudinaryUrl: response.body.secure_url
                });
            }
        });
    }


    render() { 
        return (
            <Fade in={this.props.hidden}>
                <Panel header={<h3>Branding</h3>}>
                    <Grid fluid={true}>
                        <Row>
                            <Col xs={12} md={6}>
                                <Well bsSize="large">
                                    <h4>Logo</h4>
                                    <Dropzone
                                        onDrop={this.onImageDrop.bind(this)}
                                        multiple={false}
                                        accept="image/*">
                                        <div>
                                            {this.state.uploadedFileCloudinaryUrl === '' ? null :
                                                <div>
                                                    <p>{this.state.uploadedFile.name}</p>
                                                    <img src={this.state.uploadedFileCloudinaryUrl} />
                                                </div>}
                                        </div>
                                    </Dropzone>                                  
                                </Well>
                            </Col>
                            <Col xs={12} md={6}>
                                <Well bsSize="large">
                                    <h4>Colour Theme</h4>
                                    <div className="selectedColour"></div>
                                    <SliderPicker
                                        color={ this.state.brandColour } 
                                        onChangeComplete={ this.onColourChange } />
                                </Well>
                            </Col>
                        </Row>
                    </Grid>
                </Panel>
            </Fade>
        )
   }
};

Branding.prototypes = {
    hidden: React.PropTypes.bool,
    data: React.PropTypes.object,
    onSelect:React.PropTypes.func,
};

// TODO: I could add brandColour here in props rather than state???
Branding.defaultProps = {
    hidden:true,
};

export default Branding;