import React from 'react';
import { i18n } from 'helpers/i18n';
import { DropdownButton, MenuItem, Panel, ButtonGroup, Button, Form, FormGroup, FormControl, InputGroup, Glyphicon } from 'react-bootstrap';


export const PopUserRights = () =>
    <Panel header={<h3>Pop User Rights</h3>}>
        <Form>            
            <FormGroup>
                <InputGroup>        
                    <DropdownButton
                        componentClass={InputGroup.Button}
                        id="input-dropdown-addon"
                        title="Producer">
                        <MenuItem key="1">Producer 1</MenuItem>
                        <MenuItem key="2">Producer 2</MenuItem>
                        <MenuItem key="3">Producer 3</MenuItem>
                        <MenuItem key="4">Producer 4</MenuItem>          
                    </DropdownButton>
                    <FormControl type="text" />
                </InputGroup>
            </FormGroup>
            <FormGroup>
                <InputGroup>        
                    <DropdownButton
                        componentClass={InputGroup.Button}
                        id="input-dropdown-addon"
                        title="Branch">
                        <MenuItem key="1">Branch 1</MenuItem>
                        <MenuItem key="2">Branch 2</MenuItem>
                        <MenuItem key="3">Branch 3</MenuItem>
                        <MenuItem key="4">Branch 4</MenuItem>          
                    </DropdownButton>
                    <FormControl type="text" />
                </InputGroup>
            </FormGroup>
            <FormGroup>
                <InputGroup>        
                    <DropdownButton
                        componentClass={InputGroup.Button}
                        id="input-dropdown-addon"
                        title="Role">
                        <MenuItem key="1">Super Admin</MenuItem>
                        <MenuItem key="2">Admin</MenuItem>
                        <MenuItem key="3">User</MenuItem>
                        <MenuItem key="4">Subscriber</MenuItem>          
                    </DropdownButton>
                    <FormControl type="text" />
                </InputGroup>
            </FormGroup>
            <FormGroup>
                <InputGroup>        
                    <DropdownButton
                        componentClass={InputGroup.Button}
                        id="input-dropdown-addon"
                        title="Reminder">
                        <MenuItem key="1">ON</MenuItem>
                        <MenuItem key="2">OFF</MenuItem>
                    </DropdownButton>
                    <FormControl type="text" />
                </InputGroup>
            </FormGroup>
        </Form>
    </Panel>;