import React from 'react';
import { connect } from 'react-redux';
import { Fade, Panel, Checkbox, FormGroup, InputGroup,  Button, Glyphicon } from 'react-bootstrap';
import TextInput from 'components/TextInputControl/'


class ApplicationDetails extends React.Component {

    constructor(props) {
        super(props);
        this.state = {open: false};
        this.onSelectEvent = this.onSelectEvent.bind(this);
    }


    onSelectEvent(event) {
        this.setState({open:!this.state.open});
    }





    render() { 
        return (
            <Fade in={this.props.hidden}>
                <Panel collapsible expanded={this.state.open} onSelect={this.onSelectEvent} header={<h3>{this.props.title}</h3>}>
                    <Panel header={<h3>Contect Details</h3>}>
                        <FormGroup>
                            <InputGroup>
                                                            <InputGroup.Addon>
                                    <Glyphicon glyph="search" />
                                </InputGroup.Addon>
                                <TextInput 
                                    name ='search'
                                    type = 'text'
                                    />

                             </InputGroup>                      
                        </FormGroup>    
                        <FormGroup>

                            <InputGroup>
                                <InputGroup.Addon>
                                    <Glyphicon glyph="search" />
                                </InputGroup.Addon>
                                <TextInput 
                                    name ='search'
                                    type = 'text'
                                    />
 
                             </InputGroup>                      
                        </FormGroup>   
                    </Panel>   
                    <Panel header={<h3>Payment Details</h3>}>
                        <FormGroup>
                            <Checkbox
                                inline 
                                value='recourse'
                                > 
                                MSC
                            </Checkbox>
                            {' '}
                            <Checkbox
                                inline 
                                value='nonrecourse'
                                >
                                Debit Card
                            </Checkbox>
                            {' '}
                            <Checkbox
                                inline 
                                value='nonrecourse'
                                >
                                Bank Transfer
                            </Checkbox>
                            {' '}
                            <Checkbox
                                inline 
                                value='nonrecourse'
                                >
                                Cheque
                            </Checkbox>
                        </FormGroup>   
                    </Panel> 
                </Panel>
            </Fade>
        )
    }
}


ApplicationDetails.propTypes = {
    title: React.PropTypes.string,
    hidden: React.PropTypes.bool
};

ApplicationDetails.defaultProps = {
    results:{},
    hidden:true
};


export default ApplicationDetails;
