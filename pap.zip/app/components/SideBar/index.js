import React from 'react';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import { i18n } from 'helpers/i18n';
import { ButtonGroup, Button, Glyphicon } from 'react-bootstrap';
import { StickyContainer, Sticky } from 'react-sticky';
import {browserHistory} from 'react-router';
import {navigateTo, goBack, save, logOut } from 'containers/App/actions';


class SideBar extends React.Component {

    constructor(props) {
        super(props);
        this.onMenuButtonClicked = this.onMenuButtonClicked.bind(this);
        this.onBackButtonClicked = this.onBackButtonClicked.bind(this);
        this.onSaveButtonClicked = this.onSaveButtonClicked.bind(this);
        this.onLogoutButtonClicked = this.onLogoutButtonClicked.bind(this);
    }
    
    onMenuButtonClicked(event) {
        navigateTo(event.currentTarget.value);
    }

    onLogoutButtonClicked(event) {
      this.props.logOut(event);
      navigateTo(event.currentTarget.value);
    }

    onBackButtonClicked(event) {
        goBack();
    }

    onSaveButtonClicked(event) {
      this.props.saveData(event);
    }


    render() {
        return (
          <StickyContainer className="side-bar">
            <Sticky>
                <ButtonGroup vertical block>
                  {this.props.menu.showLoginButton ? <Button bsStyle="success" onClick={this.onMenuButtonClicked} value="/login"><Glyphicon glyph="log-in" /> Login</Button> : null}
                  {this.props.menu.showLoginOutButton ? <Button bsStyle="warning" onClick={this.onLogoutButtonClicked} value="/"><Glyphicon glyph="log-out" /> Logout</Button> : null}
                  {this.props.menu.showBranchButton ? <Button  onClick={this.onMenuButtonClicked} value="/branch"><Glyphicon glyph="tree-deciduous"/> Branch</Button>: null}
                  {this.props.menu.showUserButton ? <Button  onClick={this.onMenuButtonClicked} value="/user"><Glyphicon glyph="user"/> User</Button>: null}
                  {this.props.menu.showPaymentButton ? <Button  onClick={this.onMenuButtonClicked} value="/payment-details"><Glyphicon glyph="gbp"/> Payment Details</Button>: null}
                  {this.props.menu.showBackButton ? <Button onClick={this.onBackButtonClicked}><Glyphicon glyph="arrow-left" /> Back</Button>: null}
                  {this.props.menu.showSaveButton ? <Button bsStyle="danger" onClick={this.onSaveButtonClicked}><Glyphicon glyph="save" /> Save</Button>: null}
                </ButtonGroup>
              </Sticky>
            </StickyContainer>
          )
      };
  }


SideBar.propTypes = {
    saveData: React.PropTypes.func,
    logOut: React.PropTypes.func,
};

function mapDispatchToProps(dispatch) {
  return {
    saveData: (evt) => {
      if (evt !== undefined && evt.preventDefault) evt.preventDefault();
      dispatch(save());
    },
    logOut: (evt) => {
      if (evt !== undefined && evt.preventDefault) evt.preventDefault();
      dispatch(logOut());
    },
    dispatch,
  };
}

const mapStateToProps = createStructuredSelector({

});

export default connect(mapStateToProps, mapDispatchToProps)(SideBar);
