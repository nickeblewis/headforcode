import React from 'react';
import { connect } from 'react-redux';
import { Panel, FormGroup, InputGroup,  Button, Glyphicon, Table } from 'react-bootstrap';
import TextInput from 'components/TextInputControl/'


class Search extends React.Component {

    constructor(props) {
        super(props);
        this.onSelectEvent = this.onSelectEvent.bind(this);
        this.onChange = this.onChange.bind(this);
        this.onSubmit = this.onSubmit.bind(this);
        this.resultSelected = this.resultSelected.bind(this); 
        this.buildTableOfResults = this.buildTableOfResults.bind(this);
    }


    onChange(event) {
        this.props.onChange(event);
    }


    onSubmit(event) {
        this.props.onSubmit(event);
    }


    resultSelected(event) {
        this.props.resultSelected(event);
    }


    onSelectEvent(event) {
        this.props.onExpand(event);
    }
    
    buildTableOfResults(results) {
        var self = this
        if (results.data) {
               var listItems = results.data.map(function(props) {
                return ( <tr key={props.id}>
                            <td>{props.code}</td>
                            <td>{props.name}</td>
                            <td><Button onClick={self.resultSelected}>Select</Button></td>
                        </tr>);
                });
        }
        return listItems;
    }


    render() { 
        return (
                <Panel collapsible expanded={this.props.open} onSelect={this.onSelectEvent} header={<h3>{this.props.title}</h3>}>
                    <FormGroup>
                    <InputGroup>
                        <TextInput 
                            name ='search'
                            type = 'text'
                            onChange={this.onChange}
                            />
                        <InputGroup.Button>
                            <Button onClick={this.onSubmit}><Glyphicon glyph="search" /></Button>
                        </InputGroup.Button>
                    </InputGroup>
                    </FormGroup>   
                    <Table striped bordered condensed hover>
                    <thead>
                    <tr>
                        <th>Code</th>
                        <th>Name</th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                        {this.buildTableOfResults(this.props.results)}
                    </tbody>
                </Table>
                </Panel>
        )
    }
}




Search.propTypes = {
    onChange: React.PropTypes.func,
    onSubmit: React.PropTypes.func,
    results: React.PropTypes.object,
    resultSelected: React.PropTypes.func,
    title: React.PropTypes.string,
    open: React.PropTypes.bool
};

Search.defaultProps = {
    results:{},
    open:true
};


export default Search;
