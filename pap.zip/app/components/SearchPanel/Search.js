import React from 'react';
import { connect } from 'react-redux';
import { Alert, Panel, FormGroup, InputGroup,  Button, Glyphicon, Table, Pagination } from 'react-bootstrap';
import TextInput from 'components/TextInputControl/'
import { createStructuredSelector } from 'reselect';
import { searchPageChanged } from './actions';


class Search extends React.Component {


    constructor(props) {
        super(props);
        this.state = {hidden: false, open:true, error:false};
        this.onSelectEvent = this.onSelectEvent.bind(this);
        this.onChange = this.onChange.bind(this);
        this.onSubmit = this.onSubmit.bind(this);
    }


    onChange(event) {
        this.props.onChange(event);
    }

 

    onSubmit(event) {
        this.props.onSubmit(event);
    }


    onSelectEvent(event) {
        this.props.onExpand(event);
    }  


    showErrorMessage() { 
        if(!this.props.data.success) { 
            if(this.props.data.errors.length > 0) {
                return (<Alert bsStyle="danger">
                            <strong>No Results Found!</strong>
                        </Alert>);
            }   
        }     
         return null;
    }
    
    
    showResultsTable() {
        if(this.props.data.success) {
            if(this.props.data.results.length > 0) {
                return (<div>
                        <Table striped bordered condensed hover>
                            <thead>
                                {this.props.tableHeader()}
                            </thead>
                            <tbody>
                                {this.props.itemRenderer(this.props.data, this.props.onSelect)}
                            </tbody>
                        </Table>   
                        <Pagination bsSize="small" items={this.props.data.totalPages} activePage={this.props.data.pageNumber}onSelect={this.props.handlePageSelect} />
                        </div>);
            } else {
                return (<Alert bsStyle="danger">
                            <strong>No Results Found!</strong>
                        </Alert>);
            }
        }
        return null;    
    }


    render() { 
        return (
                <Panel collapsible expanded={this.props.open} onSelect={this.onSelectEvent} header={<h3>{this.props.title}</h3>}>
                    <FormGroup>
                        <InputGroup>
                            <TextInput name ='search' type = 'text' onChange={this.onChange} />
                            <InputGroup.Button>
                                <Button onClick={this.onSubmit}><Glyphicon glyph="search" /></Button>
                            </InputGroup.Button>
                        </InputGroup>
                    </FormGroup>   
                    {this.showErrorMessage()}
                    {this.showResultsTable()}
                </Panel>
        )
    }
}


Search.propTypes = {
    onChange: React.PropTypes.func,
    onSubmit: React.PropTypes.func,
    data: React.PropTypes.object,
    tableHeader: React.PropTypes.func,
    itemRenderer:React.PropTypes.func,
    onSelect:React.PropTypes.func,
    title: React.PropTypes.string,
    open: React.PropTypes.bool,
    handlePageSelect: React.PropTypes.func
};


Search.defaultProps = {
    data:{},
    open:true
};

function mapDispatchToProps(dispatch) {
  return {
    handlePageSelect: (evt) => {
      if (evt !== undefined && evt.preventDefault) evt.preventDefault();
      dispatch(searchPageChanged(evt));
    },
    dispatch,
  };
}

const mapStateToProps = createStructuredSelector({

});


export default connect(mapStateToProps, mapDispatchToProps)(Search);