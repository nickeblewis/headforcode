import React from 'react';
import { i18n } from 'helpers/i18n';
import { Panel, Radio, Form, FormGroup } from 'react-bootstrap';

 class  BussinessTypeSelector extends React.Component {

    constructor(props) {
        super(props);
        this.onHandleClick = this.onHandleClick.bind(this);
    }

    onHandleClick(event) {
        this.props.onSelect(event.currentTarget.value);
    }

    render() {
        return (<Panel header={<h3>Producer Business Type</h3>}>
                <Form>
                    <FormGroup>
                        <Radio 
                            inline 
                            value='recourse'
                            onChange={this.onHandleClick}
                            checked={this.props.data.recourse} 
                            > 
                            Recource
                        </Radio>
                        {' '}
                        <Radio 
                            inline 
                            value='nonrecourse'
                            onChange={this.onHandleClick}
                            checked={this.props.data.nonrecourse} 
                            >
                            Non-Recource
                        </Radio>
                    </FormGroup>
                </Form>
            </Panel>);
    }
}

BussinessTypeSelector.prototypes = {
    onSelect:React.PropTypes.func,
    data:React.PropTypes.object,
}

export default BussinessTypeSelector;