import { i18n } from 'helpers/i18n';
// import { hasDipped } from 'helpers/status';
// import { Guid } from 'constants/Transaction';
import { date } from 'forms/formatters';
import { compose, map, reduce } from 'helpers/utils';

const getPolicyTotal = compose(
  reduce((acc, v) => acc += v, 0),
  map(compose(Number, ({ policyPremium }) => policyPremium))
);

export const general = {
  finance: tx => value => {
    const hasPaymentMethods = !!tx.paymentOptions.length;
    const hasFinanceOptions = !!tx.financeOptions.length;
    return hasPaymentMethods || hasFinanceOptions ?
      [] : [ { error: i18n('fieldWarnings:invalidPaymentOptions') } ];
  },
  policyLines: tx => _ => {
    const { status, policyLines, selectedFinanceOption } = tx;
    return hasDipped(status) && !policyLines.length && selectedFinanceOption !== Guid.EMPTY ?
      [ { error: i18n('fieldWarnings:noPolicyLines') } ] :
      [];
  },
  earliestStartDate: tx => _ => {
    const { policyLines, premium: { dueDate } } = tx;
    const minDate = Math.min(...policyLines.map(({ startDate }) => parseInt(startDate)));
    return policyLines.length &&  minDate !== parseInt(dueDate) ?
      [ { error: i18n('fieldWarnings:earliestStartDate')({ earliestStartDate: date.ddmmyy(dueDate) }) } ] :
      [];
  },
  totalPremium: tx => _ => {
    const { policyLines, premium: { totalPremium } } = tx;
    return policyLines.length && getPolicyTotal(policyLines) !== Number(totalPremium) ?
      [ { error: i18n('fieldWarnings:invalidPremiumAmount') } ] :
      [];
  }
};
