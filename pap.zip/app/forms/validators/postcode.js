import { i18n } from 'helpers/i18n';

export const postcode = value =>
  value === '' || /^((gir\s{0,}0aa)|((([a-pr-uwyz][a-hk-y]?[0-9][0-9]?)|(([a-pr-uwyz][0-9][a-hjkstuw])|([a-pr-uwyz][a-hk-y][0-9][abehmnprv-y])))\s{0,}[0-9][abd-hjlnp-uw-z]{2}))$/i.test(value) ?
    [] : [ { error: i18n('fieldWarnings:postcodeFormat') } ];
