import { i18n } from 'helpers/i18n';

export const required = value =>
  typeof value === 'undefined' || value === '' || value === false || typeof value === 'string' && value.trim() === '' ?
    [ { error: i18n('fieldWarnings:required') } ] :
    [];

required.boolean = value =>
  typeof value !== 'boolean' ?
    [ { error: i18n('fieldWarnings:requiredBoolean') } ] :
    [];
