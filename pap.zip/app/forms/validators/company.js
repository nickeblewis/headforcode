import { i18n } from 'helpers/i18n';

export const company = {
  registration: value =>
    !/^\d{7,8}$|(?:[A|F|I|O|R|S]C|N[A|F|I|L|O|P|R|Z]|G[E|N|S]|[I|L]P|S[A|F|I|L|O])\d{6}/.test(value) ?
      [ { error: i18n('fieldWarnings:companyRegistration') } ] : []
};
