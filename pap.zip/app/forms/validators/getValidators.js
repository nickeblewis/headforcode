import { head, last, compose, over, flatten, isNull } from 'helpers/utils';
import * as validators from 'forms/validators';

const getOrValidators = (ctx, tx, field, parentId, vs) =>
  compose(
    err => err.length < vs.length ? [] : err,
    flatten,
    over(...getValidators(ctx, tx, field, parentId, vs))
  );

export const getValidators = (ctx, tx, field, parentId, vs = null) => {
  vs = isNull(vs) ? (field.validators || []) : vs;
  const refMap = { '$ctx': ctx, '$field': field, '$parentId': parentId, '$tx': tx };
  return vs.map(v => {
    if (Array.isArray(v)) return getOrValidators(ctx, tx, field, parentId, v);
    const args = (v.indexOf('=') > -1 ? last(v.split('=')).split('|') : [])
      .map(arg => refMap[arg] || arg);
    const fn = head(v.split('='));
    const validator = fn.split('.').reduce((fn, key) => fn[key], validators);
    return args.length ? validator(...args) : validator;
  });
};

export const getFieldValidators = validatorsConfig => {
  return validatorsConfig.map(v => {
    const args = v.indexOf('=') > -1 ? last(v.split('=')).split('|') : [];
    const fn = head(v.split('='));
    const validator = fn.split('.').reduce((fn, key) => fn[key], validators);
    return args.length ? validator(...args) : validator;
  });
};
