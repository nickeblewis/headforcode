import { i18n } from 'helpers/i18n';

export const number = value =>
  isNaN(Number(value)) ? [ { error: i18n('fieldWarnings:numberFormat') } ] : [];

number.max = max => value =>
  value !== '' && Number(value) > Number(max) ? [ { error: i18n('fieldWarnings:valueHigh') } ] : [];

number.min = min => value =>
  value !== '' && Number(value) < Number(min) ? [ { error: i18n('fieldWarnings:valueLow') } ] : [];

number.fixed = range => value =>
  ((String(value).split('.')[1] || []).length) > range ? [ { error: i18n('fieldWarnings:valueFixed') } ] : [];
