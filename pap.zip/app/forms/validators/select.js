import { i18n } from 'helpers/i18n';

export const select = {
  option: field => value => {
    if (!value) return [];
    const hasPassed = field.options.some(o => o.value === value);
    return hasPassed ? [] : [ { error: i18n('fieldWarnings:notAnOption') } ];
  }
};
