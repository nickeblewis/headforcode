import { identity } from 'helpers/utils';

export const sortCode = identity;

sortCode.uk = (value = '') =>
  value.length < 6 ? value : `${value.substr(0, 2)}-${value.substr(2, 2)}-${value.substr(4, 2)}`;
