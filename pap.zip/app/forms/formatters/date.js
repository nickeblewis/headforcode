import { i18n } from 'helpers/i18n';
import { identity } from 'helpers/utils';

export const date = identity;

const getDate = value => {
  const isUtcStr = typeof value === 'string' && value.indexOf('-') === 4;
  return new Date(isUtcStr ? Date.parse(value) : Number(value));
};

const slicer = num =>
  ('00' + num).slice(-2);

// 01/01/17
date.ddmmyy = (value) => {
  const d = getDate(value);

  return `${slicer(d.getDate())}/${slicer(d.getMonth() + 1)}/${slicer(d.getFullYear())}`;
};

// 01 Jan '17
date.ddmmmyy = (value) => {
  const d = getDate(value);

  return `${slicer(d.getDate())} ${i18n(`shared:monthsShort:${d.getMonth() + 1}`)} '${slicer(d.getFullYear())}`;
};

// Sun 01 Jan
date.dayddmmm = (value) => {
  const d = getDate(value);

  return `${i18n(`shared:daysShort:${d.getDay() + 1}`)} ${slicer(d.getDate())} ${i18n(`shared:monthsShort:${d.getMonth() + 1}`)}`;
};
