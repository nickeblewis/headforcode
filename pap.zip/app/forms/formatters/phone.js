import { uk, ie } from 'forms/utils/phone';

export const phone = value => {
  if (uk.isValidFormat(value)) return uk.formatValue(value);
  if (ie.isValidFormat(value)) return ie.formatValue(value);
  return value;
};

phone.uk = value => uk.formatValue(value);
phone.ie = value => ie.formatValue(value);
