import { getAsyncInjectors } from './utils/asyncInjectors';
import { 
  LANDING_PAGE_URL, 
  LOGIN_PAGE_URL, 
  DASHBOARD_PAGE_URL, 
  PRODUCER_PAGE_URL, 
  BRANCH_PAGE_URL, 
  PAYMENT_DETAILS_PAGE_URL, 
  USER_PAGE_URL 
} from './paths';


const errorLoading = (err) => {
  console.error('Dynamic page loading failed', err); 
};

const loadModule = (callback) => (componentModule) => {
  callback(null, componentModule.default);
};

export default function createRoutes(store) {

  const { injectReducer, injectSagas } = getAsyncInjectors(store);

  return [
    {
      path: LANDING_PAGE_URL,
      name: 'home',
      getComponent(nextState, callback) {
       require.ensure([
         './containers/HomePage'
         ], function (require) {
            let index = require('./containers/HomePage').default;
            getAsyncInjectors(store, 'HomePage');
            callback(null, index);
       });
      },
    },{
      path: LOGIN_PAGE_URL,
      name: 'loginPage',
      getComponent(nextState, callback) {
        const renderRoute = loadModule(callback);
        require.ensure([
          './containers/LoginPage/reducer',
          './containers/LoginPage/sagas',
          './containers/LoginPage'
        ], function (require) {
          let component = require('./containers/LoginPage');
          let reducer = require('./containers/LoginPage/reducer');
          let sagas = require('./containers/LoginPage/sagas');
          injectReducer('loginPage', reducer.default);
          injectSagas(sagas.default);
          renderRoute(component);
        });
      }
    },{
      path: DASHBOARD_PAGE_URL,
      name: 'dashboard',
      getComponent(nextState, callback) {
       require.ensure([
         './containers/DashboardPage'
         ], function (require) {
            let index = require('./containers/DashboardPage').default;
            getAsyncInjectors(store, 'DashboardPage');
            callback(null, index);
       });
      },
    },{
      path: PRODUCER_PAGE_URL,
      name: 'producerPage',
      getComponent(nextState, callback) {
        const renderRoute = loadModule(callback);
        require.ensure([
          './containers/ProducerPage/reducer',
          './containers/ProducerPage/searchProducerSagas',
          './containers/ProducerPage/getProducerDataSagas',
          './containers/ProducerPage'
        ], function (require) {
          let component = require('./containers/ProducerPage');
          let reducer = require('./containers/ProducerPage/reducer');
          let searchProducerSagas = require('./containers/ProducerPage/searchProducerSagas');
          let getProducerDataSagas = require('./containers/ProducerPage/getProducerDataSagas');
          injectReducer('producerPage', reducer.default);
          injectSagas(searchProducerSagas.default);
          injectSagas(getProducerDataSagas.default);
          renderRoute(component);
        });
      }
    },{
      path: BRANCH_PAGE_URL,
      name: 'branchPage',
      getComponent(nextState, callback) {
        const renderRoute = loadModule(callback);
        require.ensure([
          './containers/BranchPage/reducer',
          './containers/BranchPage/sagas',
          './containers/BranchPage'
        ], function (require) {
          let component = require('./containers/BranchPage');
          let reducer = require('./containers/BranchPage/reducer');
          let sagas = require('./containers/BranchPage/sagas');
          injectReducer('branchPage', reducer.default);
          injectSagas(sagas.default);
          renderRoute(component);
        });
      }
    },{
      path: PAYMENT_DETAILS_PAGE_URL,
      name: 'paymentDetails',
      getComponent(nextState, callback) {
        const renderRoute = loadModule(callback);
       require.ensure([
         './containers/PaymentDetailsPage/reducer',
         './containers/PaymentDetailsPage/sagas',
         './containers/PaymentDetailsPage'
         ], function (require) {
            let component = require('./containers/PaymentDetailsPage');
            let reducer = require('./containers/PaymentDetailsPage/reducer');
            let sagas = require('./containers/PaymentDetailsPage/sagas');
            injectReducer('PaymentDetailsPage', reducer.default);
            injectSagas(sagas.default);
            renderRoute(component);
       });
      }
    },{
      path: USER_PAGE_URL ,
      name: 'userPage',
      getComponent(nextState, callback) {
        const renderRoute = loadModule(callback);
        require.ensure([
          './containers/UserPage/reducer',
          './containers/UserPage/sagas',
          './containers/UserPage'
        ], function (require) {
          let component = require('./containers/UserPage');
          let reducer = require('./containers/UserPage/reducer');
          let sagas = require('./containers/UserPage/sagas');
          injectReducer('userPage', reducer.default);
          injectSagas(sagas.default);
          renderRoute(component);
        });
      }
    }
  ];
}