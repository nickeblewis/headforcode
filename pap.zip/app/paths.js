export const LANDING_PAGE_URL = '/';
export const LOGIN_PAGE_URL = '/login';
export const DASHBOARD_PAGE_URL = '/dashboard';
export const PRODUCER_PAGE_URL = '/producer';
export const BRANCH_PAGE_URL = '/branch';
export const PAYMENT_DETAILS_PAGE_URL = "/payment-details"
export const USER_PAGE_URL = "/user";