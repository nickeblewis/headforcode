import 'babel-polyfill';
import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import { applyRouterMiddleware, Router, browserHistory } from 'react-router';
import { syncHistoryWithStore } from 'react-router-redux';
import useScroll from 'react-router-scroll';

//import { install } from 'offline-plugin/runtime';

import App from './containers/App';
import createRoutes from './routes';
import configureStore from './store';
import enGB from './public/i18n/enGB.json';
import { setConfig } from './helpers/service';
import { selectLocationState } from './containers/App/selectors';


Object.defineProperty(window, '_locale', {
  enumerable: false,
  configurable: true,
  writable: false,
  value: enGB.results
});


const initialState = {};
const store = configureStore(initialState, browserHistory);


if (window.devToolsExtension) {
  window.devToolsExtension.updateStore(store);
}


const history = syncHistoryWithStore(browserHistory, store, {
  selectLocationState: selectLocationState(),
});


const rootRoute = {
  component: App,
  childRoutes: createRoutes(store),
};


ReactDOM.render(
  <Provider store={store}>
    <Router
      history={history}
      routes={rootRoute}
    />
  </Provider>,
  document.getElementById('app')
);

//install();
