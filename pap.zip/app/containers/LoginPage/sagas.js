import { take, call, put, select, fork, cancel } from 'redux-saga/effects';
import { LOCATION_CHANGE } from 'react-router-redux';
import { AUTH_USER } from 'containers/App/constants';
import { authUserSucceeded, authUserFailed } from 'containers/App/actions';// import request from 'utils/request';
import { login } from 'helpers/service';
import { selectLoginFields } from 'containers/LoginPage/selectors';

export function* authUser() {
  const userDetails = yield select(selectLoginFields());
  const result = yield call(login, userDetails);
  if (result.data.Errors.length > 0) {
    if (Array.isArray(result.data.Errors) && result.data.Errors.length) {
      console.log(result.data.Errors);
      // const errors = result.data.Errors.map(error => error.value);      
      yield put(authUserFailed(result.data.Errors));
    }
  } else {
    yield put(authUserSucceeded(userDetails));
  }
}

export function* getUserWatcher() {
  while (yield take(AUTH_USER)) {
    yield call(authUser);
  }
}

export function* userData() {
  const watcher = yield fork(getUserWatcher);
  //TODO - find way if reinstating without coursing and error
 // yield take(LOCATION_CHANGE);
  //yield cancel(watcher);
}

export default [
  userData,
];
