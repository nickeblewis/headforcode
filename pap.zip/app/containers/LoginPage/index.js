import React from 'react';
import { connect } from 'react-redux';
import { push } from 'react-router-redux';
import Helmet from 'react-helmet';
import { Button, Form, FormGroup, Col, ControlLabel, Checkbox, FormControl, Alert } from 'react-bootstrap';

import { authUser } from '../App/actions';

import { changeField, verifyLogin, validateLogin } from './actions';

import { createStructuredSelector } from 'reselect';

import {
  selectCurrentUser,
  selectError,
} from 'containers/App/selectors';

import { selectFields } from './selectors';

export class LoginPage extends React.Component {
  
  componentDidMount() {
    if (this.props.fields.username && this.props.fields.username.trim().length > 0) {
      this.props.onSubmitForm();
    }
  }

  render() {
    const onFieldChange = field =>
      evt => this.props.onFieldChange({ field, value: evt.target.value });
    
    const onFieldBlur = () => {
      const isUserNamePopulated = this.props.fields.userName.value.trim() !== '';
      const isPasswordPopulated = this.props.fields.password.value.trim() !== '';

      if (isUserNamePopulated && isPasswordPopulated) {
        this.props.onValidateLogin();
      }
    };

    return (
      <div className="login-form">
        <Helmet
          title="loginPage"
          meta={[{ name: 'description', content: 'Description of loginPage'}]}
        />

        <Form horizontal onSubmit={this.props.onSubmitForm}>
          <FormGroup controlId="username" bsSize="large" validationState={this.props.error ? 'error' : null}>
            <Col componentClass={ControlLabel} sm={2}>Username</Col>
            <Col sm={10}>
              <FormControl
                id="username"
                type="text"
                placeholder="username@username.com"
                onBlur={onFieldBlur}
                onChange={onFieldChange(this.props.fields.userName)}
                value={this.props.fields.userName.value}
              />
              {this.props.fields.userName.hasInteraction ? this.props.fields.userName.errors.map(({ error, message }, i) => <ControlLabel key={i}>{error || message}</ControlLabel>) : []}
            </Col>
          </FormGroup>

          <FormGroup controlId="password" bsSize="large" validationState={this.props.error ? 'error' : null}>
            <Col componentClass={ControlLabel} sm={2}>Password</Col>
            <Col sm={10}>
              <FormControl
                id="password"
                type="password"
                placeholder="Password"
                onChange={onFieldChange(this.props.fields.password)}
                value={this.props.fields.password.value}
              />
              {this.props.fields.password.hasInteraction ? this.props.fields.password.errors.map(({ error, message }, i) => <ControlLabel key={i}>{error || message}</ControlLabel>) : []}
            </Col>
          </FormGroup>

          <FormGroup>
            <Col smOffset={2} sm={10}>
              <Button type="submit" onClick={this.onSubmitForm}>Login</Button>
            </Col>
          </FormGroup>
        </Form>
        {this.props.fields.errors.hasInteraction ? this.props.fields.password.errors.map(({ error, message }, i) => <ControlLabel key={i}>{error || message}</ControlLabel>) : []}
        {this.props.error ?
          <Alert bsStyle="danger">
            <strong>Login unsuccessful, please try again!</strong>
          </Alert> : null
        }
      </div>
    );
  }
}

LoginPage.propTypes = {
  changeRoute: React.PropTypes.func,
  loading: React.PropTypes.bool,
  error: React.PropTypes.oneOfType([
    React.PropTypes.object,
    React.PropTypes.bool,
    React.PropTypes.array,
  ]),
  data: React.PropTypes.oneOfType([
    React.PropTypes.array,
    React.PropTypes.bool,
  ]),
  onFieldChange: React.PropTypes.func,
  onVerifyLogin: React.PropTypes.func,
  onValidateLogin: React.PropTypes.func,
  onSubmitForm: React.PropTypes.func,
  fields: React.PropTypes.object,
};

function mapDispatchToProps(dispatch) {
  return {
    onFieldChange: (args) => dispatch(changeField(args)),
    changeRoute: (url) => dispatch(push(url)),
    onVerifyLogin: () => dispatch(verifyLogin()),
    onValidateLogin: () => dispatch(validateLogin()),
    onSubmitForm: (evt) => {
      if (evt !== undefined && evt.preventDefault) evt.preventDefault();
      dispatch(authUser());
    },
    dispatch,
  };
}

const mapStateToProps = createStructuredSelector({
  // data: selectCurrentUser(),
  fields: selectFields(),
  error: selectError(),
});

export default connect(mapStateToProps, mapDispatchToProps)(LoginPage);
