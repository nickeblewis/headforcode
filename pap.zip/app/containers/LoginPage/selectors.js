import { createSelector } from 'reselect';

const selectLoginPageDomain = () => (state) => state.get('loginPage');

const selectLoginPage = () => createSelector(
  selectLoginPageDomain(),
  (substate) => substate.toJS()
);

const selectFields = () => createSelector(
  selectLoginPageDomain(),
  (substate) => {
    return substate.getIn(['forms', 'login', 'fields']).toJS();
  }
);

const selectLoginFields = () => createSelector(
  selectLoginPageDomain(),
  (substate) => {
    return {
      userName: substate.getIn(['forms', 'login', 'fields', 'userName', 'value']),
      password: substate.getIn(['forms', 'login', 'fields', 'password', 'value']),  
      error: substate.getIn(['forms', 'login', 'fields', 'errors', 'value']),   
    };
  }
);

export {
  selectLoginPageDomain,
  selectLoginPage,
  selectFields,
  selectLoginFields,
};
