/* eslint-disable */

/**
 * Test  sagas
 */

// import expect from 'expect';
// import { fromJS } from 'immutable';
// import { take, call, put, select } from 'redux-saga/effects';
// import { authUser } from '../sagas';
// import { selectLoginFields } from '../selectors';
// import { login } from 'helpers/service';

// describe('defaultSaga Saga', () => {
//   it('should .....', () => {

//   });
// });
