// /* eslint-disable */

// import {   selectLoginPageDomain, selectLoginPage, selectFields, selectLoginFields } from '../selectors';
// import { fromJS } from 'immutable';
// import expect from 'expect';

// const selector = selectLoginPage();

// describe('selectLoginPageDomain', () => {
//   it('should select the login page domain', () => {
//     const global = fromJS({
//       loginPage: {
//         forms: {
//           login: {
//             fields: {
//               userName: {
//                 value: 'myusername',
//               },
//               password: {
//                 value: 'mypassword',
//               }
//             }
//           }
//         }
//       }
//     });

//     const expected = fromJS({
//       forms: {
//         login: {
//           fields: {
//             userName: {
//               value: 'myusername',
//             },
//             password: {
//               value: 'mypassword',
//             }
//           }
//         }
//       }
//     });

//     expect(selectLoginPageDomain()(global)).toEqual(expected);
//   });
// });

// describe('selectLoginPage', () => {
//   it('should select the login page in plain JS object', () => {
//     const global = fromJS({
//       loginPage: {
//         forms: {
//           login: {
//             fields: {
//               userName: {
//                 value: 'myusername',
//               },
//               password: {
//                 value: 'mypassword',
//               }
//             }
//           }
//         }
//       }
//     });

//     const expected = {
//       forms: {
//         login: {
//           fields: {
//             userName: {
//               value: 'myusername',
//             },
//             password: {
//               value: 'mypassword',
//             }
//           }
//         }
//       }
//     };

//     expect(selectLoginPage()(global)).toEqual(expected);
//   });
// });

// describe('selectFields', () => {
//   it('should select the login page fields in plain JS object', () => {
//     const global = fromJS({
//       loginPage: {
//         forms: {
//           login: {
//             fields: {
//               userName: {
//                 value: 'myusername',
//                 validators: [
//                   'required',
//                   'text.max=20',
//                   'text.min=6',
//                 ]
//               },
//               password: {
//                 value: 'mypassword',
//                 validators: [
//                   'required',
//                   'text.max=20',
//                   'text.min=8',
//                 ]
//               }
//             }
//           }
//         }
//       }
//     });

//     const expected = {
//       userName: {
//         value: 'myusername',
//         validators: [
//           'required',
//           'text.max=20',
//           'text.min=6',
//         ],
//         errors: []
//       },
//       password: {
//         value: 'mypassword',
//         validators: [
//           'required',
//           'text.max=20',
//           'text.min=8',
//         ],
//         errors: []
//       }
//     };

//     expect(selectFields()(global)).toEqual(expected);
//   });
// });

// describe('selectLoginFields', () => {
//   it('should select the bank details fields in plain JS object', () => {
//     const global = fromJS({
//       loginPage: {
//         forms: {
//           login: {
//             fields: {
//               userName: {
//                 value: 'myusername',
//               },
//               password: {
//                 value: 'mypassword',
//               }
//             }
//           }
//         }
//       }
//     });

//     const expected = {
//       userName: 'myusername',
//       password: 'mypassword'
//     };

//     expect(selectLoginFields()(global)).toEqual(expected);
//   });
// });
