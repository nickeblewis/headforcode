/* eslint-disable */

import expect from 'expect';
import {
  verifyLogin,
} from '../actions';
import {
  VERIFY_LOGIN,
} from '../constants';

describe('LoginPage actions', () => {
  describe('verifyLogin Action', () => {
    it('has a type of VERIFY_LOGIN', () => {
      const expected = {
        type: VERIFY_LOGIN,
      };
      expect(verifyLogin()).toEqual(expected);
    });
  });
});
