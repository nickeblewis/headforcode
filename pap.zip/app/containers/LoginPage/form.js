// import { getFieldValidators } from 'forms/validators/getValidators';

const fields = {
  userName: {
    name: 'userName',
    type: 'email',
    validators: [
      'required',
    ],
  },
  password: {
    name: 'password',
    type: 'text',
    validators: [
      'required',
    ],
  },
  errors: {
    name: 'errors',
    type: 'text',
  }
};

export const getFields = () => {
  const mappedFields = {};
  Object.entries(fields).forEach(([fieldName, field]) => {
    mappedFields[fieldName] = {
      ...field, value: '', errors: [], hasInteraction: false
    };
  });
  return mappedFields;
};

export const validate = fields => {
  const fieldErrors = {};

  fields.forEach(field => {
    const validators = getFieldValidators(field.validators);
  });

  return fieldErrors;
};
