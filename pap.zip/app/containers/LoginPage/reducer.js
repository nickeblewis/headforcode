/*
 *
 * LoginPage reducer
 *
 */
import { getFields as getLoginFields } from 'containers/LoginPage/form';
import { fromJS } from 'immutable';
import {
  CHANGE_FIELD,
  UPDATE_FIELDS,
  VERIFY_LOGIN,
  VALIDATE_LOGIN,
} from './constants';

const initialState = fromJS({
  forms: {
    login: {
      fields: getLoginFields()
    }
  }
});

const updatableFieldProps = ['value', 'errors'];

function loginPageReducer(state = initialState, action) {
  switch (action.type) {
    case CHANGE_FIELD:
      return state
        .setIn(['forms', 'login', 'fields', action.field.name, 'value'], action.value)
        .setIn(['forms', 'login', 'fields', action.field.name, 'hasInteraction'], true);

    case UPDATE_FIELDS:
      return Object.entries(action.updates).reduce((outerAccState, [fieldName, propChanges]) =>
            Object.entries(propChanges).reduce((innerAccState, [propName, propValue]) => {
              let newState;
              if (updatableFieldProps.indexOf(propName) === -1) {
                throw new Error(`Updating field property '${propName}' is not allowed`);
              }

              newState = innerAccState.setIn(['forms', 'login', 'fields', fieldName, propName], propValue);

              if (propName === 'value') {
                newState = newState.setIn(['forms', 'login', 'fields', fieldName, 'hasInteraction'], true);
              }

              return newState;
            }, outerAccState)
          , state);
    case VERIFY_LOGIN:
      return state
        .setIn(['forms', 'login', 'fields', 'userName', 'errors'], [])
        .setIn(['forms', 'login', 'fields', 'password', 'errors'], [])
        .setIn(['forms', 'login', 'fields', 'errors'], []);
    case VALIDATE_LOGIN:
      return state
        .setIn(['forms', 'login', 'fields', 'userName', 'errors'], [])
        .setIn(['forms', 'login', 'fields', 'password', 'errors'], [])
        .setIn(['forms', 'login', 'fields', 'errors'], []);
    default:
      return state;
  }
}

export default loginPageReducer;
