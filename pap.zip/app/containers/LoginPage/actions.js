import {
  CHANGE_FIELD,
  UPDATE_FIELDS,
  VERIFY_LOGIN,
  VALIDATE_LOGIN,
} from './constants';


export function changeField({ field, value }) {
  return {
    type: CHANGE_FIELD,
    field,
    value
  };
}


export function updateFields(updates) {
  return {
    type: UPDATE_FIELDS,
    updates
  };
}


export function verifyLogin() {
  return {
    type: VERIFY_LOGIN,
  };
}


export function validateLogin() {
  return {
    type: VALIDATE_LOGIN,
  };
}