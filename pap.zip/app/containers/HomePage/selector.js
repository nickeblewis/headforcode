import { createSelector } from 'reselect';

export const selectGlobalDomain = () => (state) => state.get('global');



export const selectMenu = () => createSelector(
  selectGlobalDomain(),
    (substate) => {
      return {
        data: substate.getIn(['sideMenu'])
      }
  }
);

