import React from 'react';
import Helmet from 'react-helmet';
import { createStructuredSelector } from 'reselect';
import selectMenu from './selector';

class HomePage extends React.Component {

  render() {
    return (
      <div>
        <Helmet
          title="Home Page"
          meta={[
            { name: 'description', content: 'PoP Admin Portal' },
          ]}
        />
        <main>
          <section className="page dashboard">
            <h1>PAP</h1>
            <h2>Admin Portal</h2>
            <p>The data held on Premium Credit host system is PRIVATE PROPERTY. Access to the data is only available for authorised users and purposes. Unauthorised entry contravenes the Computer Misuse Act of 1990 and may incur criminal penalties as well as damages. Please proceed if you are an authorised user.</p>
          </section>
        </main>
      </div>
    );
  }
}



export default HomePage;