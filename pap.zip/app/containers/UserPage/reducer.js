import { fromJS } from 'immutable';
import { SEARCH_USER, CHANGE_FIELD, GET_USER_SUCCESS, REGISTER_USER } from './constants';
import { getFields } from './form';


const initialState = fromJS({
  forms:{
    userSearch:{
      fields:getFields()
    }
  },
  searchResults: {
  }
});


function UserReducer(state = initialState, action) {
  
  switch (action.type) {
    case SEARCH_USER:
      return state
    case CHANGE_FIELD:
        return state
          .setIn(['forms', 'userSearch', 'fields', action.field.name, 'value'], action.field.value);
    case GET_USER_SUCCESS:
      return state
          .setIn(['searchResults', 'results'], action.data.data.results);
    case REGISTER_USER:
      return state
        .set('userId', action.userId);
    default:
      return state;
  }
}


export default UserReducer;
