import { take, call, put, select, fork, cancel } from 'redux-saga/effects';
import {delay} from 'redux-saga'
import { LOCATION_CHANGE } from 'react-router-redux';
import { SEARCH_USER, CHANGE_FIELD} from './constants';
import { selectSearchFields } from './selectors'
import { getRegisteredUsers } from 'helpers/service';
import { getUserSuccess, getUserFail } from './actions';


export function* searchUser() {
    const searchDetails = yield select(selectSearchFields());
    
    const result = yield call(getRegisteredUsers, searchDetails); 
      console.log('searchUser', result)   
    if (result.data.errors.length > 0) {
        if (Array.isArray(result.data.errors) && result.data.errors.length) {
            const errors = result.data.errors.map(error => error.message);
            yield put(getUserFail(errors));
        }
    } else {

        yield put(getUserSuccess(result));

       
    }
}


export function* getUserSearchWatcher() {
    while (yield take(SEARCH_USER)) {
        yield call(searchUser);
    }
}


export function* userData() {
    const watcher = yield fork(getUserSearchWatcher);
    yield take((LOCATION_CHANGE));
    yield cancel(watcher)
}


export default [
    userData,
];
