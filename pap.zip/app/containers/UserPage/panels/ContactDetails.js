import React from 'react';
import { connect } from 'react-redux';
import { Panel, Form, FormGroup, InputGroup,  FormControl,  Glyphicon } from 'react-bootstrap';
import TextInput from 'components/TextInputControl/'


class ContactDetails extends React.Component {

    constructor(props) {
        super(props);
        this.state = {open: true};
        this.onSelectEvent = this.onSelectEvent.bind(this);
    }


    onSelectEvent(event) {
        this.setState({open:!this.state.open});
    }


    render() { 
        return (
  
                <Panel collapsible expanded={this.state.open} onSelect={this.onSelectEvent} header={<h3>Contact Details</h3>}> 
                    <Form>
                        <FormGroup>
                            <InputGroup>
                                <InputGroup.Addon>@</InputGroup.Addon>
                                <FormControl type="text" placeholder="Email Address"/>
                            </InputGroup>
                        </FormGroup>
                        <FormGroup>
                            <InputGroup>
                                <InputGroup.Addon><Glyphicon glyph="phone" /></InputGroup.Addon>
                                <FormControl type="text"  placeholder="Phone Number"/>
                            </InputGroup>
                        </FormGroup>
                    </Form>    
                </Panel>
      
        )
    }
}

ContactDetails.propTypes = {
    title: React.PropTypes.string,
    hidden: React.PropTypes.bool
};

ContactDetails.defaultProps = {
    results:{},
    hidden:true
};


export default ContactDetails;
