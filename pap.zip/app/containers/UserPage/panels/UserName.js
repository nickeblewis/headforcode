import React from 'react';
import { connect } from 'react-redux';
import { Panel, Form, FormGroup, InputGroup,  FormControl,  Glyphicon } from 'react-bootstrap';
import TextInput from 'components/TextInputControl/'


class UserName extends React.Component {

    constructor(props) {
        super(props);
        this.state = {open: true};
        this.onSelectEvent = this.onSelectEvent.bind(this);
    }


    onSelectEvent(event) {
        this.setState({open:!this.state.open});
    }


    render() { 
        return (
  
                <Panel collapsible expanded={this.state.open} onSelect={this.onSelectEvent} header={<h3>User</h3>}> 
                    <Form>
                        <FormGroup>
                            <InputGroup>
                                <InputGroup.Addon><Glyphicon glyph="user" /></InputGroup.Addon>
                                <FormControl type="text" placeholder="User Name"/>
                            </InputGroup>
                        </FormGroup>
                    </Form>    
                </Panel>
      
        )
    }
}

UserName.propTypes = {
    title: React.PropTypes.string,
    hidden: React.PropTypes.bool
};

UserName.defaultProps = {
    results:{},
    hidden:true
};


export default UserName;
