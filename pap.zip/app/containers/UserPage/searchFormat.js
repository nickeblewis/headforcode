import React from 'react';
import { Button } from 'react-bootstrap';

 export function header() {
    return (<tr>
                <th>Code</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>POP</th>
                <th>ABC</th>
                <th>XYZ</th>
                <th></th>
            </tr>);
}

    

export function itemRenderer(results, callback) {
    var self = this
    if (results.data) {
            var listItems = results.data.map(function(props) {
            return ( <tr key={props.code}>
                        <td>{props.code}</td>
                        <td>{props.firstName}</td>
                        <td>{props.lastName}</td>
                        <td>{props.pop}</td>
                        <td>{props.abc}</td>
                        <td>{props.xyz}</td>
                        <td><Button onClick={callback}>Register</Button></td>
                    </tr>);
            });
    }
    return listItems;
}