const fields = {
  search: {
    name: 'userSearch', 
    type: 'text',  
    validators: []
  }
};



export const getFields = () => {
  const mappedFields = {};
  Object.entries(fields).forEach(([fieldName, field]) => {
    mappedFields[fieldName] = {
      ...field, value: '', errors: [], hasInteraction: false
    };
  });
  return mappedFields;
};


