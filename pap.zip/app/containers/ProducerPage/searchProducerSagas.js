import { take, call, put, select, fork, cancel } from 'redux-saga/effects';
import {delay} from 'redux-saga'
import { LOCATION_CHANGE } from 'react-router-redux';
import { SEARCH_PRODUCER, CHANGE_FIELD, PRODUCER_SELECTED} from './constants';
import { selectSearchFields } from './selectors'
import { getRecourceProducers, getSelectedProducer } from 'helpers/service';
import { getProducerSuccess, getProducerFail } from './actions';
import { searchPageChanged } from 'components/SearchPanel/actions';
import { SEARCH_PAGE_CHANGE } from 'components/SearchPanel/constants';

export function* searchProducer() {
    const searchDetails = yield select(selectSearchFields());
    
    const result = yield call(getRecourceProducers, searchDetails);  
    if(result.data.Success) {
        yield put(getProducerSuccess(result.data));
    } else {
        if (Array.isArray(result.data.Errors) && result.data.Errors.length) {
            const errors = result.data.Errors.map(error => error.value);
            yield put(getProducerFail(errors));
        }
    }
}


export function* getProduerSearchWatcher() {
    while (yield take([SEARCH_PRODUCER, SEARCH_PAGE_CHANGE])) {
        yield call(searchProducer);
    }


}

export function* producerData() {
    const watcher = yield fork(getProduerSearchWatcher);
    yield take((LOCATION_CHANGE));
    yield cancel(watcher)
}


export default [
    producerData,
];
