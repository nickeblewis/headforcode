import React from 'react';
import Helmet from 'react-helmet';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import { PageHeader , Button } from 'react-bootstrap';

import { selectFields, selectSearchResult, selectBusinessType, selectBrandColour } from './selectors'

import Search from 'components/SearchPanel/Search';
import Branding from 'components/BrandingPanel/';
import { ContactDetails } from 'components/ContactDetailsPanel/ContactDetailsPanel.jsx';
import  BussinessTypeSelector  from 'components/BussinessTypeSelectorPanel/';
import AvailableApplicationSelector from 'components/AvailableApplicationSelector/';
import { changeField, searchProducer, changeBusinessType, changeBrandColour, producerSelected  } from './actions';
import { header, itemRenderer } from './searchFormat';

class ProducerPage extends React.Component {
  
  constructor(props) {
      super(props);
      this.state = {hidden: false, open:true};
      this.searchInputChanged = this.searchInputChanged.bind(this);
      this.searchSubmitted = this.searchSubmitted.bind(this);
      this.searchResultSelected = this.searchResultSelected.bind(this);
      this.expandSearch = this.expandSearch.bind(this);
      this.onSelectBusinessType = this.onSelectBusinessType.bind(this);
      this.onSelectBrandColour = this.onSelectBrandColour.bind(this);
  }

  onSelectBusinessType(event) {
    this.props.onBusinessTypeChanged(event);
  }

  onSelectBrandColour(event) {
    this.props.onBrandColourChanged(event);
  }

  searchInputChanged(event) {
    var field = event;
    this.props.onSearchFieldChanged(field);
  }

  searchSubmitted(event) {
    this.props.onSearchClicked(event);
  }

  searchResultSelected(event) {
    //this.setState({hidden:true});
    this.props.onSearchResultClicked(event);
    //this.setState({open:!this.state.open});
  }

  expandSearch(event) {
    this.setState({open:!this.state.open});
  }

  render() {
    return (
      <div className="producer">
        <Helmet
          title="Producer Onboarding"
          meta={[{ name: 'description', content: 'PoP Admin Portal' }]}
        />
        <PageHeader>Producer Onboarding</PageHeader>

        <Search
          open={this.state.open} 
          title="Search for Producers" 
          onExpand={this.expandSearch}  
          onChange={this.searchInputChanged} 
          onSubmit={this.searchSubmitted} 
          onSelect={this.searchResultSelected} 
          data={this.props.results}
          tableHeader={header}
          itemRenderer={itemRenderer}
        />
        <Branding onSelect={this.onSelectBrandColour} hidden={this.state.hidden} data={this.props.brandColour} />
 
      </div>
    );      
  }  
}

ProducerPage.propTypes = {
  onBusinessTypeChanged: React.PropTypes.func,
  onSearchFieldChanged: React.PropTypes.func,
  onSearchClicked: React.PropTypes.func,
  onBrandColourChanged: React.PropTypes.func,
  onSearchResultClicked:React.PropTypes.func,
};

function mapDispatchToProps(dispatch) {
  return {
    onSearchFieldChanged: (args) => dispatch(changeField(args)),
    onSearchClicked: (evt) => {
      if (evt !== undefined && evt.preventDefault) evt.preventDefault();
      dispatch(searchProducer());
    },
     onSearchResultClicked: (evt) => {
      if (evt !== undefined && evt.preventDefault) evt.preventDefault();
      dispatch(producerSelected(evt));
    },
    onBusinessTypeChanged: (args) => dispatch(changeBusinessType(args)),
    onBrandColourChanged: (args) => dispatch(changeBrandColour(args)),
    dispatch,
  };
}

const mapStateToProps = createStructuredSelector({
    fields: selectFields(),
    results: selectSearchResult(),
    businessType:selectBusinessType(),
    brandColour:selectBrandColour(),
});

export default connect(mapStateToProps, mapDispatchToProps)(ProducerPage);

