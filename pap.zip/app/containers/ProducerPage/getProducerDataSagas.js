import { take, call, put, select, fork, cancel } from 'redux-saga/effects';
import {delay} from 'redux-saga'
import { LOCATION_CHANGE } from 'react-router-redux';
import { SEARCH_PRODUCER, CHANGE_FIELD, PRODUCER_SELECTED} from './constants';
import { selectSearchFields } from './selectors'
import { getRecourceProducers, getSelectedProducer } from 'helpers/service';
import { getProducerSuccess, getProducerFail } from './actions';
import { searchPageChanged } from 'components/SearchPanel/actions';
import { SEARCH_PAGE_CHANGE } from 'components/SearchPanel/constants';


export function* producerSelected() {
    const searchDetails = yield select(selectSearchFields());
    
    const result = yield call(getSelectedProducer, searchDetails);  

   /* if(result.data.Success) {
        yield put(getProducerSuccess(result.data));
    } else {
        if (Array.isArray(result.data.Errors) && result.data.Errors.length) {
            const errors = result.data.Errors.map(error => error.value);
            yield put(getProducerFail(errors));
        }
    }*/
}


export function* getProduerSearchResultSelectedWatcher() {
    while (yield take(PRODUCER_SELECTED)) {
        yield call(producerSelected);
    }
}


export function* getSelectedProducerData() {
    const watcher = yield fork(getProduerSearchResultSelectedWatcher);
    yield take((LOCATION_CHANGE));
    yield cancel(watcher)
}


export default [
    getSelectedProducerData,
];
