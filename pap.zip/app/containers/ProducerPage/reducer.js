import { fromJS, Immutable } from 'immutable';
import { SEARCH_PRODUCER, CHANGE_FIELD, GET_PRODUCER_SUCCESS, CHANGE_BUSINESSTYPE, CHANGE_LOGO, CHANGE_COLOUR, PRODUCER_SELECTED} from './constants';
import { getFields } from './form';
import { SEARCH_PAGE_CHANGE } from 'components/SearchPanel/constants';

const initialState = fromJS({
  businessType:"nonrecourse",
  brandColour: "",
  forms:{
    producerSearch:{
      fields:getFields()
    }
  },
  searchResults: {
    PageNumber:1,
    PageSize:10,
    Results:[],
    Errors:[],
    TotalPages:false,
    TotalResults:false,
    Success:false
  }
});


function ProducerReducer(state = initialState, action) {
  switch (action.type) {
    case SEARCH_PRODUCER:
      return state
    case CHANGE_FIELD:
        return state
          .setIn(['forms', 'producerSearch', 'fields', action.field.name, 'value'], action.field.value);
    case GET_PRODUCER_SUCCESS:
      return state
          .setIn(['searchResults', 'Results'], action.data.Results)
          .setIn(['searchResults', 'Errors'], action.data.Errors)
          .setIn(['searchResults', 'PageNumber'], action.data.PageNumber)
          .setIn(['searchResults', 'PageSize'], action.data.PageSize)
          .setIn(['searchResults', 'TotalPages'], action.data.TotalPages)
          .setIn(['searchResults', 'TotalResults'], action.data.TotalResults)
          .setIn(['searchResults', 'Success'], action.data.Success);
    case CHANGE_BUSINESSTYPE:
      return state
          .setIn(['businessType'], action.data);
    case CHANGE_LOGO:
      return state
        .setIn(['producerLogo'], action.data);
    case CHANGE_COLOUR:
      return state
        .setIn(['brandColour'], action.data);
    case PRODUCER_SELECTED:
      return state
        .setIn(['producerDetails'], action.data);
    case SEARCH_PAGE_CHANGE:
      return state
        .setIn(['searchResults', 'PageNumber'], action.data)
    default:
      return state;
  }
}


export default ProducerReducer;
