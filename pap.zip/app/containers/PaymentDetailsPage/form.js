// TODO - revisit Emrah's notes under Story 6686 (later on as name of field changes)
const fields = {
  credentials: {
    name: 'XML Credentials',
    type: 'text',
    validators: {}
  },
  fees: {
    name: 'Facility Fees',
    type: 'text',
    validators: {}
  },
  msc: {
    name: 'MSC',
    type: 'text',
    validators: {}
  },
  payments: {
    name: 'Payments',
    type: 'text',
    validators: {}
  },
  transfer: {
    name: 'Transfer',
    type: 'text',
    validators: {}
  }
}

export const getFields = () => {
  const mappedFields = {};
  Object.entries(fields).forEach(([fieldName, field]) => {
    mappedFields[fieldName] = {
      ...field, value: '', errors: [], hasInteraction: false
    };
  });
  return mappedFields;
};