export { createSelector} from 'reselect';

export const selectPaymentPanelDomain = () => (state) => state.get('paymentPage'); 

export const selectFields = () => createSelector(
  selectSearchPanelDomain(),
  (substate) => {
    return substate.getIn(['forms', 'producerSearch', 'fields']).toJS();
  }
);