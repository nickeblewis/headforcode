import React from 'react';
import { connect } from 'react-redux';
import { Panel, Form, FormGroup, FormControl, InputGroup, Glyphicon } from 'react-bootstrap';
import TextInput from 'components/TextInputControl/'


class CardPayments extends React.Component {

    constructor(props) {
        super(props);
        this.state = {open: true};
        this.onSelectEvent = this.onSelectEvent.bind(this);
    }


    onSelectEvent(event) {
        this.setState({open:!this.state.open});
    }


    render() { 
        return (
  
                <Panel collapsible expanded={this.state.open} onSelect={this.onSelectEvent} header={<h3>Card Payments</h3>}> 
                    <Form>
                        <FormGroup>
                            <InputGroup>
                                <InputGroup.Addon><Glyphicon glyph="user" /></InputGroup.Addon>
                                <FormControl type="text"  placeholder="Payment Profile ID"/>
                            </InputGroup>
                        </FormGroup>
                        <FormGroup>
                            <InputGroup>
                                <InputGroup.Addon><Glyphicon glyph="user" /></InputGroup.Addon>
                                <FormControl type="text" placeholder="Broker ID"/>
                            </InputGroup>
                        </FormGroup>
                    </Form>  
                    <Panel header={<h3>Card Charges</h3>}> 
                        <ul>
                            <li><strong>Visa</strong>  = 1.5%</li>
                            <li><strong>Master Card</strong>  = 1.5%</li>
                            <li><strong>Amex</strong>  = 1.5%</li>
                        </ul>  
                    </Panel>
                </Panel>
      
        )
    }
}

CardPayments.propTypes = {
    title: React.PropTypes.string,
    hidden: React.PropTypes.bool
};

CardPayments.defaultProps = {
    results:{},
    hidden:true
};


export default CardPayments;
