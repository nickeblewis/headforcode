import React from 'react';
import { connect } from 'react-redux';
import { Table, Fade, Panel, Checkbox, FormGroup, FormControl, InputGroup,  Button, Glyphicon } from 'react-bootstrap';
import TextInput from 'components/TextInputControl/'


class FacilitiesFees extends React.Component {

    constructor(props) {
        super(props);
        this.state = {open: true};
        this.onSelectEvent = this.onSelectEvent.bind(this);
    }


    onSelectEvent(event) {
        this.setState({open:!this.state.open});
    }


    render() { 
        return (
  
                <Panel collapsible expanded={this.state.open} onSelect={this.onSelectEvent} header={<h3>Facility Fees</h3>}> 
                    <div className="panel-body ">
                        <div className="text-center">
                            <div className="inline ">                
                                <FormControl type="text" className="range" value="0" ></FormControl> -                   
                                <FormControl type="text" className="range" value="1000" ></FormControl> =>
                                <FormControl type="text" className="range" value="5" ></FormControl>
                            </div>  
                        </div> 
                        <Button className="btn btn-default" type="button" >
                            <Glyphicon glyph="plus" />
                        </Button>                     
                    </div>
                </Panel>
      
        )
    }
}


FacilitiesFees.propTypes = {
    title: React.PropTypes.string,
    hidden: React.PropTypes.bool
};

FacilitiesFees.defaultProps = {
    results:{},
    hidden:true
};


export default FacilitiesFees;
