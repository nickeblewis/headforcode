export const GET_PAYMENT_DETAILS = 'app/DetailsPanel/GET_PAYMENT_DETAILS';
export const CHANGE_FIELD = 'app/DetailsPanel/CHANGE_FIELD';