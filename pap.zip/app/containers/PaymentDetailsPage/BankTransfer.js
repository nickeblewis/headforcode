import React from 'react';
import { connect } from 'react-redux';
import { Panel, Form, FormGroup, InputGroup,  FormControl,  Glyphicon } from 'react-bootstrap';
import TextInput from 'components/TextInputControl/'


class BankTransfer extends React.Component {

    constructor(props) {
        super(props);
        this.state = {open: true};
        this.onSelectEvent = this.onSelectEvent.bind(this);
    }


    onSelectEvent(event) {
        this.setState({open:!this.state.open});
    }


    render() { 
        return (
  
                <Panel collapsible expanded={this.state.open} onSelect={this.onSelectEvent} header={<h3>Bank Transfer</h3>}> 
                    <Form>
                        <FormGroup>
                            <InputGroup>
                                <InputGroup.Addon><Glyphicon glyph="user" /></InputGroup.Addon>
                                <FormControl type="text" placeholder="Acount Name"/>
                            </InputGroup>
                        </FormGroup>
                        <FormGroup>
                            <InputGroup>
                                <InputGroup.Addon>?</InputGroup.Addon>
                                <FormControl type="text"  placeholder="Sort Code"/>
                            </InputGroup>
                        </FormGroup>
                        <FormGroup>
                            <InputGroup>
                                <InputGroup.Addon>?</InputGroup.Addon>
                                <FormControl type="text"  placeholder="Account Number"/>
                            </InputGroup>
                        </FormGroup>
                    </Form>    
                </Panel>
      
        )
    }
}

BankTransfer.propTypes = {
    title: React.PropTypes.string,
    hidden: React.PropTypes.bool
};

BankTransfer.defaultProps = {
    results:{},
    hidden:true
};


export default BankTransfer;
