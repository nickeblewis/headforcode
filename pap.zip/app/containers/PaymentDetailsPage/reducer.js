import { fromJS } from 'immutable';
import { CHANGE_FIELD, GET_PAYMENT_DETAILS } from './constants';
import { getFields } from './form';

const initialState = fromJS({
  forms:{
    paymentDetails: {
      fields:getFields()
    }
  }
});

function PaymentDetailsReducer(state = initialState, action) {
  
  switch (action.type) {
    case GET_PAYMENT_DETAILS:
      return state
    case CHANGE_FIELD:
        return state
          .setIn(['forms', 'paymentDetails', 'fields', action.field.name, 'value'], action.field.value);
    default:
      return state;
  }
}

export default PaymentDetailsReducer