import React from 'react';
import Helmet from 'react-helmet';
import { createStructuredSelector } from 'reselect';
import { PageHeader } from 'react-bootstrap';
import XMLCredentials from './XMLCredentials';
import FacilitiesFees from './FacilitiesFees';
import Msc from './Msc';
import CardPayments from './CardPayments';
import BankTransfer from './BankTransfer';

class PaymentDetailsPage extends React.Component {

  render() {
    return (
      <div>
        <Helmet
          title="Home Page"
          meta={[
            { name: 'description', content: 'PoP Admin Portal' },
          ]}
        />
        <div className="paymentDetails">
            <PageHeader>Payment Details</PageHeader>
            <XMLCredentials />
            <FacilitiesFees />
            <Msc />
            <CardPayments />
            <BankTransfer />

         </div>
      </div>
    );
  }
}



export default PaymentDetailsPage;