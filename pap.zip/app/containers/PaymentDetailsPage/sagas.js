import { take, call, put, select, fork, cancel } from 'redux-saga/effects';
import {delay} from 'redux-saga'
import { LOCATION_CHANGE } from 'react-router-redux';
import { GET_PAYMENT_DETAILS, CHANGE_FIELD} from './constants';
import { selectPaymentDetailsFields } from './selectors'
import { getPaymentDetails } from 'helpers/service';
//import { getProducerSuccess, getProducerFail } from './actions';

export function* getPayment() {
    const paymentDetails = yield select(selectPaymentDetailsFields());    
    const result = yield call(getPaymentDetails, paymentDetails);

    if (result.data.errors.length > 0) {
        if (Array.isArray(result.data.errors) && result.data.errors.length) {
            const errors = result.data.errors.map(error => error.message);
            yield put(getPaymentFail(errors));
        }
    } else {
        yield put(getPaymentSuccess(result));       
    }
}

export function* getPaymentWatcher() {
    while (yield take(GET_PAYMENT_DETAILS)) {
        yield call(getPaymentDetails);
    }
}

export function* paymentData() {
    const watcher = yield fork(getPaymentWatcher);
    yield take((LOCATION_CHANGE));
    yield cancel(watcher)
}

export default [
    paymentData,
];