import { GET_PAYMENT_DETAILS }  from './constants';

export function getPaymentDetails() {
  return {
    type: GET_PAYMENT_DETAILS,
    data
  };
}

export function changeField(field) {
  return {
    type: CHANGE_FIELD,
    field
  };
}