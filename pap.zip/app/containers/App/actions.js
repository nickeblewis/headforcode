import {
  AUTH_USER,
  AUTH_USER_SUCCESS,
  AUTH_USER_FAILURE,
  LOAD_I18N,
  SAVE,
  LOG_OUT,
} from './constants';

import { 
  DASHBOARD_PAGE_URL,
  USER_PAGE_URL,
  PRODUCER_PAGE_URL
} from 'paths';


import {browserHistory} from 'react-router';

export function authUser() {
  return {
    type: AUTH_USER,
  };
}

export function authUserSucceeded(data) {
  navigateTo(DASHBOARD_PAGE_URL);
  return {
    type: AUTH_USER_SUCCESS,
    data,
  };
}

export function authUserFailed(error) {
  return {
    type: AUTH_USER_FAILURE,
    error,
  };
}

export function loadI18n() {
  return {
    type: LOAD_I18N,
  };
}

export function navigateToUser() {
  navigateTo(USER_PAGE_URL);
}

export function navigateToProducer() {
  navigateTo(PRODUCER_PAGE_URL);
}

export function navigateTo(url) {
   browserHistory.push(url)
}

export function goBack() {
  browserHistory.goBack();
}

export function save() {
   return {
    type: SAVE,
  };
}

export function logOut() {
  return {
    type: LOG_OUT,
  }
}