import { 
  LANDING_PAGE_URL, 
  LOGIN_PAGE_URL, 
  DASHBOARD_PAGE_URL, 
  PRODUCER_PAGE_URL, 
  BRANCH_PAGE_URL, 
  PAYMENT_DETAILS_PAGE_URL, 
  USER_PAGE_URL 
} from 'paths';

import { PRODUCER_SELECTED } from 'containers/ProducerPage/constants'

const initMenu = {
  menu: {
    showLoginButton:true,
    showLoginOutButton:false,
    showBranchButton:false,
    showUserButton:false,
    showPaymentButton:false,
    showBackButton:false,
    showSaveButton:false
  }
};


const loginMenu = {
  menu: {
    showLoginButton:false,
    showLoginOutButton:false,
    showBranchButton:false,
    showUserButton:false,
    showPaymentButton:false,
    showBackButton:true,
    showSaveButton:false
  }
};


const dashboardMenu = {
  menu: {
    showLoginButton:false,
    showLoginOutButton:true,
    showBranchButton:false,
    showUserButton:false,
    showPaymentButton:false,
    showBackButton:true,
    showSaveButton:false
  }
};


const producerMenu = {
  menu: {
    showLoginButton:false,
    showLoginOutButton:true,
    showBranchButton:false,
    showUserButton:true,
    showPaymentButton:false,
    showBackButton:true,
    showSaveButton:true
  }
};

const producerMenuSelected = {
  menu: {
    showLoginButton:false,
    showLoginOutButton:true,
    showBranchButton:true,
    showUserButton:true,
    showPaymentButton:true,
    showBackButton:true,
    showSaveButton:true
  }
};


export const getMenuProps = (url) => {
  const mappedFields = {};
  var menu = {};
  switch (url) {
    case LANDING_PAGE_URL:
      menu = initMenu;
      break;
    case LOGIN_PAGE_URL:
      menu = loginMenu;
      break;
    case DASHBOARD_PAGE_URL:
      menu = dashboardMenu;
      break;
    case PRODUCER_PAGE_URL:
      menu = producerMenu;
      break;
    case PRODUCER_SELECTED:
      menu = producerMenuSelected;
      break;
    default:
      menu = producerMenuSelected;
  }
  Object.entries(menu).forEach(([fieldName, field]) => {
    mappedFields[fieldName] = {
      ...menu
    };
  });
  return mappedFields;
};