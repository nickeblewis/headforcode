/**
 * The global state selectors
 */

import { createSelector } from 'reselect';

const selectGlobal = () => (state) => state.get('global');

const selectCurrentUser = () => createSelector(
  selectGlobal(),
  (globalState) => globalState.get('currentUser')
);

const selectCurrentUserName = () => createSelector(
  selectGlobal(),
  (globalState) => globalState.get('currentUserName')
);

const selectLoading = () => createSelector(
  selectGlobal(),
  (globalState) => globalState.get('loading')
);

const selectError = () => createSelector(
  selectGlobal(),
  (globalState) => globalState.get('error')
);

const selectMenu = () => createSelector(
  selectGlobal(),
  (globalState) => {
    var map = globalState.getIn(['sideMenu', 'menu', 'menu'])
    var json = JSON.stringify(map);
    return JSON.parse(json);
  }
);

const selectLocationState = () => {
  let prevRoutingState;
  let prevRoutingStateJS;

  return (state) => {
    const routingState = state.get('route'); // or state.route

    if (!routingState.equals(prevRoutingState)) {
      prevRoutingState = routingState;
      prevRoutingStateJS = routingState.toJS();
    }

    return prevRoutingStateJS;
  };
};

export {
  selectGlobal,
  selectCurrentUser,
  selectCurrentUserName,
  selectLoading,
  selectError,
  selectLocationState,
  selectMenu
};