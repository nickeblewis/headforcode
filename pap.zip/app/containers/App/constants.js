export const AUTH_USER = 'app/App/AUTH_USER';
export const AUTH_USER_SUCCESS = 'app/App/AUTH_USER_SUCCESS';
export const AUTH_USER_FAILURE = 'app/App/AUTH_USER_FAILURE';
export const LOAD_I18N = 'app/App/LOAD_I18N';
export const SAVE = 'app/App/SAVE';
export const LOG_OUT = 'app/App/LOG_OUT';
