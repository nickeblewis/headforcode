import { AUTH_USER_SUCCESS, AUTH_USER, AUTH_USER_FAILURE, LOG_OUT } from './constants';
import { PRODUCER_SELECTED } from 'containers/ProducerPage/constants'
import { LOCATION_CHANGE } from 'react-router-redux';
import { getMenuProps, getSelectedProducerMenuProps } from './menu';
import { fromJS } from 'immutable';


const initialState = fromJS({
  loading: false,
  error: false,
  currentUser: false,
  currentUserName: false,
  selectedProducer: false,
  userIsAuthenticated: false,
  sideMenu:getMenuProps()
});


function appReducer(state = initialState, action) {
  switch (action.type) {
    case AUTH_USER:
      return state
        .set('loading', true)
        .set('userIsAuthenticated', false)
        .set('error', false);
    case AUTH_USER_SUCCESS:
      return state
        .set('loading', false)
        .set('userIsAuthenticated', true)
        .set('currentUserName', action.data.userName)
        .set('error', action.error);
    case AUTH_USER_FAILURE:
      return state
        .set('error', action.error)
        .set('userIsAuthenticated', false)
        .set('currentUserName', '')
        .set('loading', false);
    case LOG_OUT:
      return state
        .set('userIsAuthenticated', false)
        .set('currentUserName', '');
    case  LOCATION_CHANGE:
      var obj = fromJS(getMenuProps(action.payload.pathname));
     return state
        .set('sideMenu', obj);
    case PRODUCER_SELECTED:
      var obj = fromJS(getMenuProps(PRODUCER_SELECTED));
     return state
        .set('sideMenu', obj)
        .set('selectedProducer',  action.data);
    default:
      return state;
  }
}


export default appReducer;
