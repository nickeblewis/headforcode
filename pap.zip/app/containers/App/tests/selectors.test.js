import { fromJS } from 'immutable';
import expect from 'expect';

import { selectCurrentUser, selectError, selectGlobal, selectLocationState, selectLoading } from 'containers/App/selectors';

describe('selectLocationState', () => {
  it('should select the route as a plain JS object', () => {
    const route = fromJS({
      locationBeforeTransitions: null,
    });
    const mockedState = fromJS({
      route,
    });
    expect(selectLocationState()(mockedState)).toEqual(route.toJS());
  });
});

describe('selectGlobal', () => {
  it('should select the global', () => {
    const global = fromJS({
      val: 1,
    });
    const mockedState = fromJS({
      global,
    });
    expect(selectGlobal()(mockedState).toJS()).toEqual(global.toJS());
  });
});

describe('selectCurrentUser', () => {
  it('should select the current user', () => {
    const user = fromJS({
        id: 1,
        name: 'test user'
    });
    const global = fromJS({
      currentUser: user,
    });
    const mockedState = fromJS({
      global,
    });
    expect(selectCurrentUser()(mockedState).toJS()).toEqual(user.toJS());
  });
});


describe('selectLoading', () => {
  it('should select the loading as plain JS object', () => {
    const loading = fromJS({
      val1: 'val1',
      name: 'test user'
    });
    const global = fromJS({
      loading: loading,
    });
    const mockedState = fromJS({
      global,
    });
    expect(selectLoading()(mockedState).toJS()).toEqual(loading.toJS());
  });
});

describe('selectError', () => {
  it('should select the error', () => {
    const global = fromJS({
      error: 1,
    });
    const mockedState = fromJS({
      global,
    });

    expect(selectError()(mockedState)).toEqual(1);
  });
});
