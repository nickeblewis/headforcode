import { loadI18nSaga } from './loadI18nSaga';
import { saveSaga } from './saveSaga';
export { loadI18nSaga };
export { saveSaga };
export default [loadI18nSaga, saveSaga];
