
import { take, call, put, select, fork, cancel } from 'redux-saga/effects';
import { LOCATION_CHANGE } from 'react-router-redux';
import { SAVE } from 'containers/App/constants';

import request from 'utils/request';

export function* saveRequest() {
    console.log('SAVE')
  const requestURL = 'http://localhost:3000/i18n/enGB.json';


  const result = yield call(request, requestURL, body);

  if (!result.err) {
    console.log(result);
  } else {

  }
}

export function* getWatcher() {
  while (yield take(SAVE)) {
    yield call(saveRequest);
  }
}


export function* saveSaga() {
    console.log('SAVE')
  const watcher = yield fork(getWatcher);
}


export default [
  saveSaga,
];
