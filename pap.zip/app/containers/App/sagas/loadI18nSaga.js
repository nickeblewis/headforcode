/**
 * @todo: currently unused, do we really need to allow dynamic reloading of application strings?
 */

import { take, call, put, select, fork, cancel } from 'redux-saga/effects';
import { LOCATION_CHANGE } from 'react-router-redux';
import { LOAD_I18N } from 'containers/App/constants';

import request from 'utils/request';

export function* loadI18nRequest() {

  const requestURL = 'http://localhost:3000/i18n/enGB.json';

  // Call our request helper (see 'utils/request')
  const result = yield call(request, requestURL, body);

  // TODO: this needs to be streamlined / reused
  if (!result.err) {
    console.log(result);
  } else {
    // Dispatch server-side error (i.e. 500) action
    // yield console.log(result.err);
  }
}

export function* getWatcher() {
  while (yield take(LOAD_I18N)) {
    yield call(loadI18nRequest);
  }
}

/**
 * Root saga manages watcher lifecycle
 */
export function* loadI18nSaga() {
  // Fork watcher so we can continue execution
  const watcher = yield fork(getWatcher);
}

// Bootstrap sagas
export default [
  loadI18nSaga,
];
