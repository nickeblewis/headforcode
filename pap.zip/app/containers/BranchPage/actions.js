import { SEARCH_BRANCH, CHANGE_FIELD, GET_BRANCH_SUCCESS, GET_BRANCH_FAIL } from './constants';


export function searchBranch() {
    return {
        type: SEARCH_BRANCH,
    };
}


export function changeField(field) {
  return {
    type: CHANGE_FIELD,
    field
  };
}


export function getBranchSuccess(data) {
  return {
    type: GET_BRANCH_SUCCESS,
    data
  };
}


export function getBranchFail(data) {
  return {
    type: GET_BRANCH_SUCCESS,
    data
  };
}