export const SEARCH_BRANCH = 'app/BranchPanel/SEARCH_PRODUCER';
export const CHANGE_FIELD = 'app/BranchPanel/CHANGE_FIELD';
export const GET_BRANCH_SUCCESS = 'app/BranchPanel/GET_BRANCH_SUCCESS';
export const GET_BRANCH_FAIL= 'app/BranchPanel/GET_BRANCH_FAIL';