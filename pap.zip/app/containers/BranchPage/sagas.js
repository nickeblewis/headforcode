import { take, call, put, select, fork, cancel } from 'redux-saga/effects';
import {delay} from 'redux-saga'
import { LOCATION_CHANGE } from 'react-router-redux';
import { SEARCH_BRANCH, CHANGE_FIELD} from './constants';
import { selectSearchFields } from './selectors'
import { getRecourceBranches } from 'helpers/service';
import { getBranchSuccess, getBranchFail } from './actions';
import { SEARCH_PAGE_CHANGE } from 'components/SearchPanel/constants';

export function* searchBranch() {
    const searchDetails = yield select(selectSearchFields());
    const result = yield call(getRecourceBranches, searchDetails);    
    if(result.data.Success) {
        yield put(getBranchSuccess(result.data));
    } else {
        if (Array.isArray(result.data.Errors) && result.data.Errors.length) {
            const errors = result.data.Errors.map(error => error.value);
            yield put(getBranchFail(errors));
        }
    }
}


export function* getBranchSearchWatcher() {
    while (yield take([SEARCH_BRANCH, SEARCH_PAGE_CHANGE])) {
        yield call(searchBranch);
    }
}





export function* branchData() {
    const watcher = yield fork(getBranchSearchWatcher);
    yield take((LOCATION_CHANGE));
    yield cancel(watcher)
}


export default [
    branchData,
];
