import React from 'react';
import { Button } from 'react-bootstrap';

 export function header() {
    return (<tr>
                <th>Code</th>
                <th>Name</th>
                <th></th>
            </tr>);
}

    

export function itemRenderer(data, callback) {
   if (data.results) {
       var index = 0;
        var listItems = data.results.map(function(props) {
            index++;
            return ( <tr key={index}>
                        <td>{props.Code}</td>
                        <td>{props.Name}</td>
                        <td><Button onClick={callback(props.code)}>Select</Button></td>
                    </tr>);
        });
    }
    return listItems;
}