import { createSelector } from 'reselect';

export const selectSearchPanelDomain = (state) => state.get('branchPage');
export const selectGlobal = (state) => state.get('global');

export const selectSearchPanel = () => createSelector(
  selectSearchPanelDomainn(),
  (substate) => substate.toJS()
);


export const selectFields = () => createSelector(
  [selectSearchPanelDomain],
  (substate) => {
    return substate.getIn(['forms', 'branchSearch', 'fields']).toJS();
  }
);


export const selectSearchFields = () => createSelector(
  [selectSearchPanelDomain, selectGlobal],
  (substate, globalState) => {
    return {
      ProducerCode:  globalState.get('selectedProducer').Code,
      SearchText: substate.getIn(['forms', 'branchSearch', 'fields',  'search', 'value']),  
      PageNumber:substate.getIn(['searchResults', 'PageNumber']),  
      PageSize:substate.getIn(['searchResults', 'PageSize']),  
    };
  }
)


export const selectSearchResult = () => createSelector(
  [selectSearchPanelDomain],
  (substate) => {
      return {
        results: substate.getIn(['searchResults', 'Results']),
        totalPages: substate.getIn(['searchResults', 'TotalPages']),
        pageNumber: substate.getIn(['searchResults', 'PageNumber']),
        errors: substate.getIn(['searchResults', 'Errors']),
        success: substate.getIn(['searchResults', 'Success'])
      }
  }
)


export const selectProducerDetails = () => createSelector(
  [selectGlobal],
  (globalState) => {
      return globalState.get('selectedProducer');
  }
)