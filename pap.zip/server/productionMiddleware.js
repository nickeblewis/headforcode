import express from 'express';
import path from 'path';
import compression from 'compression';
import services from './services';
import cookieSession from 'cookie-session';

const addMiddlewares = (app, config) => {
    const publicPath = options.publicPath || '/';
    const outputPath = options.outputPath || path.resolve(process.cwd(), 'build');
    app.use(compression());
    app.use(publicPath, express.static(outputPath));

    app.get('*', (req, res) => res.sendFile(path.resolve(outputPath, 'index.html'))); 
};

module.exports = (app, options) => {
    addMiddlewares(app, options);
    return app;
};