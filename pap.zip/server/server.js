import express from 'express';
import logger from './logger';
import middlewareFactory from './middlewareFactory';



import bodyParser from 'body-parser';
import path from 'path';


let app = express();


app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));


middlewareFactory(app, {
  outputPath: path.resolve(process.cwd(), 'build'),
  publicPath:'/'
});


app.listen(8089, function onStart(err) {
  if(err) {
    logger.error(err);
  }
  logger.appStarted("8089");
});
