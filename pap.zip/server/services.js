'use strict';
import path from 'path';
import fs  from 'fs';
import express from 'express';
import url from 'url';
import logger from './logger';


const mocks = path.join(__dirname, './mocks/');
const camelCased = str => str.replace(/\-([a-z^\-])/g, (m, g) => g[0].toUpperCase());



const getMock = (req, res, next) => {
  let mock = path.join(mocks, camelCased(req.baseUrl.replace('/service', '')));
  logger.endpoint(req.baseUrl);
  try {
    fs.statSync(mock);
  } catch (e) {
    mock = path.join(mocks, '404.json');
  }
  res.send(require(mock));
};



function Routes(session) {
  var router = express.Router();
  router.use('*', [ session, getMock ]);
  return router;
}

module.exports = Routes;