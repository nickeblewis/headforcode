import express from 'express';
import path from 'path';
import compression from 'compression';
import services from './services';
import cookieSession from 'cookie-session';

const addMiddlewares = (app, webpackConfig) => {
    const  webpack = require('webpack');
    const  webpackDevMiddleware = require('webpack-dev-middleware');
    const  webpackHotMiddleware = require('webpack-hot-middleware');
    const compiler = webpack(webpackConfig);
    const devMiddleware = webpackDevMiddleware(compiler, {
        noInfo: true,
        publicPath: webpackConfig.output.publicPath,
        silent: true,
        stats:'errors-only'
    });
    const STATIC_ASSETS_PATH = `${process.cwd()}/statics`;
    const cookie = {
        path: '/',
        domain: '.localhost',
        maxage: 1000 * 60 * 60,
    };
    const session = cookieSession({
        name: 'app.sess',
        keys: ['secret'],
        cookie,
    });

    app.use(devMiddleware);
    app.use(webpackHotMiddleware(compiler));  

    app.use('/service', services(session));    
    app.use('/assets', express.static(path.resolve(`${STATIC_ASSETS_PATH}/assets`)));
    app.use('/styles', express.static(path.resolve(`${STATIC_ASSETS_PATH}/styles`)));
    app.use('/i18n', express.static(path.resolve(`${STATIC_ASSETS_PATH}/i18n`)));
    app.get('*', (req, res) => {
        res.sendFile(path.resolve(`${STATIC_ASSETS_PATH}/index.html`));
    });
};

module.exports = (app, options) => {
    addMiddlewares(app, require('../webpack.config'));
    return app;
};