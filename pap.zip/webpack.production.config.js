var path = require('path');
var webpack = require('webpack');

const config = {
  context:__dirname + "/app",
  devtool:'eval',//'cheap-module-source-map',
  entry: [
    'webpack-hot-middleware/client',
    __dirname + "/app/app.js"
  ],
  output: {
    path:__dirname + "/statics",
    filename: 'bundle.js'
  },
  resolve: {
    root:path.resolve("./app")
  },
  plugins: [
    new webpack.optimize.UglifyJsPlugin({minimize: true}), 
    new webpack.HotModuleReplacementPlugin()
  ],
  module: {
    loaders: [{
      test: /\.js$/,
      exclude: /(node_modules|bower_components)/,
      loader: 'babel',
      query:{
        presets: ["es2015", "stage-0", "react"]
      }
    },{
      test: /\.jsx$/,
      exclude: /(node_modules|bower_components)/,
      loader: 'babel',
      query:{
        presets: ["es2015", "stage-0", "react"]
      }
    },{
      test: /\.json$/,
      exclude: /(node_modules|bower_components)/,
      loader: 'json'
    },{
      test: /\.css$/,
      exclude: /(node_modules|bower_components)/,
      loader: 'css'
    }]
  }
};



module.exports = config;
