import { getAsyncInjectors } from './utils/asyncInjectors';


const errorLoading = (err) => {
  console.error('Dynamic page loading failed', err); 
};

const loadModule = (callback) => (componentModule) => {
  callback(null, componentModule.default);
};

export default function createRoutes(store) {

  const { injectReducer, injectSagas } = getAsyncInjectors(store);

  return [
    {
      path: '/',
      name: 'home',
      getComponent(nextState, callback) {
       require.ensure([
         './containers/HomePage'
         ], function (require) {
            let index = require('./containers/HomePage').default;
            getAsyncInjectors(store, 'HomePage');
            callback(null, index);
       });
      },
    },{
      path: '/login',
      name: 'loginPage',
      getComponent(nextState, callback) {
        const renderRoute = loadModule(callback);
        require.ensure([
          './containers/LoginPage/reducer',
          './containers/LoginPage/sagas',
          './containers/LoginPage'
        ], function (require) {
          let component = require('./containers/LoginPage');
          let reducer = require('./containers/LoginPage/reducer');
          let sagas = require('./containers/LoginPage/sagas');
          injectReducer('loginPage', reducer.default);
          injectSagas(sagas.default);
          renderRoute(component);
        });
      }
    },{
      path: '/dashboard',
      name: 'dashboard',
      getComponent(nextState, callback) {
       require.ensure([
         './containers/DashboardPage'
         ], function (require) {
            let index = require('./containers/DashboardPage').default;
            getAsyncInjectors(store, 'DashboardPage');
            callback(null, index);
       });
      },
    },{
      path: '/producer',
      name: 'producerPage',
      getComponent(nextState, callback) {
        const renderRoute = loadModule(callback);
        require.ensure([
          './containers/ProducerPage/reducer',
          './containers/ProducerPage/sagas',
          './containers/ProducerPage'
        ], function (require) {
          let component = require('./containers/ProducerPage');
          let reducer = require('./containers/ProducerPage/reducer');
          let sagas = require('./containers/ProducerPage/sagas');
          injectReducer('producerPage', reducer.default);
          injectSagas(sagas.default);
          renderRoute(component);
        });
      }
    },{
      path: '/branch',
      name: 'branchPage',
      getComponent(nextState, callback) {
        const renderRoute = loadModule(callback);
        require.ensure([
          './containers/BranchPage/reducer',
          './containers/BranchPage/sagas',
          './containers/BranchPage'
        ], function (require) {
          let component = require('./containers/BranchPage');
          let reducer = require('./containers/BranchPage/reducer');
          let sagas = require('./containers/BranchPage/sagas');
          injectReducer('branchPage', reducer.default);
          injectSagas(sagas.default);
          renderRoute(component);
        });
      }
    },{
      path: '/payment-details',
      name: 'paymentDetails',
      getComponent(nextState, callback) {
       require.ensure([
         './containers/PaymentDetailsPage'
         ], function (require) {
            let index = require('./containers/PaymentDetailsPage').default;
            getAsyncInjectors(store, 'PaymentDetailsPage');
            callback(null, index);
       });
      }
    },{
      path: '/user',
      name: 'userPage',
      getComponent(nextState, callback) {
        const renderRoute = loadModule(callback);
        require.ensure([
          './containers/UserPage/reducer',
          './containers/UserPage/sagas',
          './containers/UserPage'
        ], function (require) {
          let component = require('./containers/UserPage');
          let reducer = require('./containers/UserPage/reducer');
          let sagas = require('./containers/UserPage/sagas');
          injectReducer('userPage', reducer.default);
          injectSagas(sagas.default);
          renderRoute(component);
        });
      }
    }
  ];
}