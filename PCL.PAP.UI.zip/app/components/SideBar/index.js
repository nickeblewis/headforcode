import React from 'react';
import { i18n } from 'helpers/i18n';
import { ButtonGroup, Button, Glyphicon } from 'react-bootstrap';
import { StickyContainer, Sticky } from 'react-sticky';
import {navigateToLogin, navigateToPayment, navigateToUser, navigateToLogout, navigateToBranch, navigateToBack, saveChanges } from 'containers/App/actions';



class SideBar extends React.Component {

   render() { 
      //console.log('sidebar', this.props.menu)
        return (
        <StickyContainer className="side-bar">
          <Sticky>
              <ButtonGroup vertical block>
                <Button bsStyle="success" onClick={navigateToLogin}><Glyphicon glyph="log-in" /> Login</Button> 
                <Button bsStyle="warning" onClick={navigateToLogout}><Glyphicon glyph="log-out" /> Logout</Button> 
              </ButtonGroup>
              <ButtonGroup vertical block>
                <Button  onClick={navigateToBranch}><Glyphicon glyph="tree-deciduous"/> Branch</Button>
                <Button  onClick={navigateToUser}><Glyphicon glyph="user"/> User</Button>
                <Button  onClick={navigateToPayment}><Glyphicon glyph="gbp"/> Payment Details</Button>
                <Button  onClick={navigateToBack}><Glyphicon glyph="arrow-left" /> Back</Button>
              </ButtonGroup>
              <ButtonGroup vertical block>
                <Button bsStyle="danger"><Glyphicon glyph="save" /> Save</Button>
              </ButtonGroup>
            </Sticky>
          </StickyContainer>
        )
   };
}

SideBar.propTypes = {

};

export default SideBar;

/*
        <StickyContainer className="side-bar">
          <Sticky>
              <ButtonGroup vertical block>
                {this.props.menu.showLoginButton ? <Button bsStyle="success" onClick={navigateToLogin}><Glyphicon glyph="log-in" /> Login</Button> : null}
                {this.props.menu.showLoginOutButton ? <Button bsStyle="warning" onClick={navigateToLogout}><Glyphicon glyph="log-out" /> Logout</Button> : null}
              </ButtonGroup>
              <ButtonGroup vertical block>
                {this.props.menu.showBranchButton ? <Button  onClick={navigateToBranch}><Glyphicon glyph="tree-deciduous"/> Branch</Button>: null}
                {this.props.menu.showBackButton ? <Button  onClick={navigateToBack}><Glyphicon glyph="arrow-left" /> Back</Button>: null}
              </ButtonGroup>
              <ButtonGroup vertical block>
                {this.props.menu.showSaveButton ? <Button bsStyle="danger"><Glyphicon glyph="save" /> Save</Button>: null}
              </ButtonGroup>
            </Sticky>
          </StickyContainer>
          */