import React from 'react';
import { connect } from 'react-redux';
import {FormControl} from 'react-bootstrap';


class TextInputControl extends React.Component {

    constructor(props) {
        super(props);
        this.onChange = this.onChange.bind(this);
        this.getField = this.getField.bind(this);
    }

    onChange(event) {
        this.props.onChange(this.getField(event.target.value));
    }

    getField(value) {
        return {
                    name: this.props.name, 
                    type: this.props.type,  
                    validators: this.props.validators, 
                    value:value, 
                    errors: this.props.errors, 
                    hasInteraction: this.props.hasInteraction
                }
    }

    render() { 
        return (
                <FormControl 
                    name={this.props.name} 
                    type={this.props.type} 
                    onChange={this.onChange}
                />
        )
    }
}


TextInputControl.propTypes = {
    validators: React.PropTypes.array,
    errors: React.PropTypes.array,
    hasInteraction: React.PropTypes.bool
};

TextInputControl.defaultProps = {
    validators: [],
    errors: [],
    hasInteraction: false

};



export default TextInputControl;
