import React from 'react';
import { i18n } from 'helpers/i18n';
import { Panel, ButtonGroup, Button, Form, FormGroup, FormControl, InputGroup, Glyphicon } from 'react-bootstrap';


export const ContactDetails = () =>
    <Panel header={<h3>Producer Contact Details</h3>}>
        <Form>
            <FormGroup>
                <InputGroup>
                    <InputGroup.Addon>@</InputGroup.Addon>
                    <FormControl type="email" />
                </InputGroup>
            </FormGroup>
            <FormGroup>
                <InputGroup>
                    <InputGroup.Addon><Glyphicon glyph="phone-alt" /></InputGroup.Addon>
                    <FormControl type="number" />
                </InputGroup>
            </FormGroup>
        </Form>
    </Panel>;