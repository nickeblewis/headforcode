import React from 'react';
import { connect } from 'react-redux';
import { Table, Fade, Panel, Checkbox, FormGroup, InputGroup,  Button, Glyphicon } from 'react-bootstrap';
import TextInput from 'components/TextInputControl/'


class AvailableApplicationSelector extends React.Component {

    constructor(props) {
        super(props);
        this.state = {open: true};
        this.onSelectEvent = this.onSelectEvent.bind(this);
    }


    onSelectEvent(event) {
        this.setState({open:!this.state.open});
    }


    render() { 
        return (
            <Fade in={this.props.hidden}>
                <Panel collapsible expanded={this.state.open} onSelect={this.onSelectEvent} header={<h3>{this.props.title}</h3>}> 

                    <Table striped bordered condensed hover>
                    <thead>
                    <tr>
                        <th>POP</th>
                        <th>XYZ</th>
                        <th>XYZ</th>
                        <th>XYZ</th>
                    </tr>
                    </thead>
                    <tbody>
                        <tr >
                            <td><Checkbox value='pop'></Checkbox></td>
                            <td><Checkbox value='pop'></Checkbox></td>
                            <td><Checkbox value='pop'></Checkbox></td>
                            <td><Checkbox value='pop'></Checkbox></td>
                        </tr>
                    </tbody>
                    </Table>    
                </Panel>
            </Fade>
        )
    }
}


AvailableApplicationSelector.propTypes = {
    title: React.PropTypes.string,
    hidden: React.PropTypes.bool
};

AvailableApplicationSelector.defaultProps = {
    results:{},
    hidden:true
};


export default AvailableApplicationSelector;
