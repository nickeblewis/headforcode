import React from 'react';
import { connect } from 'react-redux';
import {Alert} from 'react-bootstrap';


class AlertPanel extends React.Component {

    constructor(props) {
        super(props);
    }

    render() {
       
        return (
            <Alert bsStyle={this.props.style}>
                <h4>Error Name</h4>
                <p>Error description to go in here</p>
                
            </Alert>        
        )
    }
}

AlertPanel.propTypes = {
    validators: React.PropTypes.array,
    errors: React.PropTypes.array,
    hasInteraction: React.PropTypes.bool,
    style: React.PropTypes.string
};

AlertPanel.defaultProps = {
    validators: [],
    errors: [],
    hasInteraction: false

};

export default AlertPanel;
