import React from 'react';
import { i18n } from 'helpers/i18n';
import { Panel, FormGroup, InputGroup, FormControl, ButtonGroup, Button, Glyphicon, Table, Pagination } from 'react-bootstrap';


export const Search = () =>
    <Panel header={<h3>Search for Producer</h3>}>
        <FormGroup>
        <InputGroup>
            <FormControl type="text" />
            <InputGroup.Button>
            <Button><Glyphicon glyph="search" /></Button>
            </InputGroup.Button>
        </InputGroup>
        </FormGroup>

        <Table striped bordered condensed hover>
        <thead>
            <tr>                       
                <th>Code</th>
                <th>Name</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>001</td>  
                <td>Producer 1</td>
                <td>Registered</td>
            </tr>
            <tr>
                <td>002</td>
                <td>Producer 2</td>
                <td><Button>Select</Button></td>
            </tr>
            <tr>
                <td>003</td>
                <td>Producer 3</td>
                <td><Button>Select</Button></td>
            </tr>
            <tr>
                <td>004</td>
                <td>Producer 4</td>
                <td><Button>Select</Button></td>
            </tr>
            <tr>
                <td>005</td>
                <td>Producer 5</td>
                <td>Registered</td>
            </tr>
        </tbody>
        </Table>
        <Pagination bsSize="small" items={10} />
    </Panel>;