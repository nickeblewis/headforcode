import { fromJS } from 'immutable';
import { SEARCH_BRANCH, CHANGE_FIELD, GET_BRANCH_SUCCESS} from './constants';
import { getFields } from './form';


const initialState = fromJS({
  forms:{
    branchSearch:{
      fields:getFields()
    }
  },
  searchResults: {
  }
});


function BranchReducer(state = initialState, action) {
  
  switch (action.type) {
    case SEARCH_BRANCH:
      return state
    case CHANGE_FIELD:
        return state
          .setIn(['forms', 'branchSearch', 'fields', action.field.name, 'value'], action.field.value);
    case GET_BRANCH_SUCCESS:
        return state
          .setIn(['searchResults', 'results'], action.data.data.results);
    default:
      return state;
  }
}


export default BranchReducer;
