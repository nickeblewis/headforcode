import { createSelector } from 'reselect';

export const selectSearchPanelDomain = () => (state) => state.get('branchPage');

export const selectSearchPanel = () => createSelector(
  selectSearchPanelDomainn(),
  (substate) => substate.toJS()
);


export const selectFields = () => createSelector(
  selectSearchPanelDomain(),
  (substate) => {
    return substate.getIn(['forms', 'branchSearch', 'fields']).toJS();
  }
);


export const selectSearchFields = () => createSelector(
  selectSearchPanelDomain(),
  (substate) => {
    return {
      filter: substate.getIn(['forms', 'branchSearch', 'fields',  'search', 'value']),  
    };
  }
)


export const selectSearchResult = () => createSelector(
  selectSearchPanelDomain(),
  (substate) => {
      return {
        data: substate.getIn(['searchResults', 'results'])
      }
  }
)
