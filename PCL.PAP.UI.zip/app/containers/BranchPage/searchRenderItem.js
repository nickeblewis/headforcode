import React from 'react';


class SearchRenderItem extends React.Component {

   render() { 
        return (
                 <tr>
                    <td>{this.props.code}</td>
                    <td>{this.props.name}</td>
                    <td>Button</td>
                </tr>
        )
   }
};

SearchRenderItem.propTypes = {
    code:React.PropTypes.string,
    name:React.PropTypes.string
};

SearchRenderItem.defaultProps = {
    code:"000",
    name:"Test"
};

export default SearchRenderItem;