import React from 'react';
import Helmet from 'react-helmet';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import { PageHeader } from 'react-bootstrap';

import { selectFields, selectSearchResult } from './selectors'

import Search from 'components/SearchPanel/Search';
import Branding from 'components/BrandingPanel/';
import { ContactDetails } from 'components/ContactDetailsPanel/ContactDetailsPanel.jsx';
import  ApplicationDetailsPanel from 'components/ApplicationDetailsPanel/';
import AlertPanel from 'components/AlertPanel/'
import { changeField, searchBranch } from './actions';
import { header, itemRenderer } from './searchFormat';


class BranchPage extends React.Component {
  

  constructor(props) {
      super(props);
      this.state = {hidden: false, open:true};
      this.searchInputChanged = this.searchInputChanged.bind(this);
      this.searchSubmitted = this.searchSubmitted.bind(this);
      this.searchResultSelected = this.searchResultSelected.bind(this);
      this.expandSearch = this.expandSearch.bind(this);
  }


  searchInputChanged(event) {
    var field = event;
    this.props.onSearchFieldChanged(field);
  }


  searchSubmitted(event) {
    this.props.onSearchClicked(event);
  }


  searchResultSelected(event) {
    this.setState({hidden:true});
    this.setState({open:!this.state.open});
  }


  expandSearch(event) {
    this.setState({open:!this.state.open});
  }


  render() {
    return (      
      <div className="producer">
        <AlertPanel 
          style="danger"
        />
        <Helmet
          title="Branch Onboarding"
          meta={[{ name: 'description', content: 'PoP Admin Portal' }]}
        />
        <PageHeader>Branch Onboarding</PageHeader>
        <Search open={this.state.open} 
                title="Search for Branch" 
                onExpand={this.expandSearch} 
                onChange={this.searchInputChanged} 
                onSubmit={this.searchSubmitted} 
                onSelect={this.searchResultSelected} 
                results={this.props.results}
                tableHeader={header}
                itemRenderer={itemRenderer}
                />        
        <Branding hidden={this.state.hidden}/>
        <ApplicationDetailsPanel hidden={this.state.hidden} title="POP Application Details"/>
        <ApplicationDetailsPanel hidden={this.state.hidden} title="XYZ Application Details"/>
        <ApplicationDetailsPanel hidden={this.state.hidden} title="XYZ Application Details"/>
      </div>
    );      
  }
}

BranchPage.propTypes = {
  onSearchFieldChanged: React.PropTypes.func,
  onSearchClicked: React.PropTypes.func
};


function mapDispatchToProps(dispatch) {
  return {
    onSearchFieldChanged: (args) => dispatch(changeField(args)),
    onSearchClicked: (evt) => {
      if (evt !== undefined && evt.preventDefault) evt.preventDefault();
      dispatch(searchBranch());
    },
    dispatch,
  };
}


const mapStateToProps = createStructuredSelector({
    fields: selectFields(),
    results: selectSearchResult()
});



export default connect(mapStateToProps, mapDispatchToProps)(BranchPage);