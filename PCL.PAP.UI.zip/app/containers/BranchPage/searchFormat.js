import React from 'react';
import { Button } from 'react-bootstrap';

 export function header() {
    return (<tr>
                <th>Code</th>
                <th>Name</th>
                <th></th>
            </tr>);
}

    

export function itemRenderer(results, callback) {
    var self = this
    if (results.data) {
        var listItems = results.data.map(function(props) {
        return ( <tr key={props.code}>
                    <td>{props.code}</td>
                    <td>{props.name}</td>
                    <td><Button onClick={callback(props.code)}>Select</Button></td>
                </tr>);
        });
    }
    return listItems;
}