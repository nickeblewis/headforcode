import { take, call, put, select, fork, cancel } from 'redux-saga/effects';
import {delay} from 'redux-saga'
import { LOCATION_CHANGE } from 'react-router-redux';
import { SEARCH_BRANCH, CHANGE_FIELD} from './constants';
import { selectSearchFields } from './selectors'
import { getRecourceBranches } from 'helpers/service';
import { getBranchSuccess, getBranchFail } from './actions';


export function* searchBranch() {
    const searchDetails = yield select(selectSearchFields());
    const result = yield call(getRecourceBranches, searchDetails);    
    if (result.data.errors.length > 0) {
        if (Array.isArray(result.data.errors) && result.data.errors.length) {
            const errors = result.data.errors.map(error => error.message);
            yield put(getBranchFail(errors));
        }
    } else {
        yield put(getBranchSuccess(result));
    }
}


export function* getBranchSearchWatcher() {
    while (yield take(SEARCH_BRANCH)) {
        yield call(searchBranch);
    }
}


export function* branchData() {
    const watcher = yield fork(getBranchSearchWatcher);
    yield take((LOCATION_CHANGE));
    yield cancel(watcher)
}


export default [
    branchData,
];
