/*
 *
 * DashboardPage
 *
 */

import React from 'react';
import { connect } from 'react-redux';
import Helmet from 'react-helmet';
import { Button, ButtonToolbar } from 'react-bootstrap';
import {navigateToUser, navigateToProducer } from '../../containers/App/actions';

export default class DashboardPage extends React.Component { n

  render() {
    return (
      <div className="dashboard" >
        <Helmet
          title="DashboardPage"
          meta={[
            { name: 'description', content: 'Admin Dashboard' },
          ]}
        />
        <ButtonToolbar className="dashboard-button-bar">
          <Button className="dashboard-button"   onClick={navigateToProducer}>Register a Producer</Button>
          <Button className="dashboard-button"   onClick={navigateToUser}>Register a User</Button>
        </ButtonToolbar>
      </div>
    );
  }
}

