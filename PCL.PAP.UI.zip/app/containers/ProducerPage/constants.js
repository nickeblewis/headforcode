export const SEARCH_PRODUCER = 'app/SearchPanel/SEARCH_PRODUCER';
export const CHANGE_FIELD = 'app/SearchPanel/CHANGE_FIELD';
export const GET_PRODUCER_SUCCESS = 'app/SearchPanel/GET_PRODUCER_SUCCESS';
export const GET_PRODUCER_FAIL= 'app/SearchPanel/GET_PRODUCER_FAIL';
export const CHANGE_BUSINESSTYPE = 'app/SearchPanel/CHANGE_BUSINESSTYPE';
export const CHANGE_LOGO = 'app/SearchPanel/CHANGE_LOGO';
export const CHANGE_COLOUR = 'app/SearchPanel/CHANGE_COLOUR';