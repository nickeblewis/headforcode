import { take, call, put, select, fork, cancel } from 'redux-saga/effects';
import {delay} from 'redux-saga'
import { LOCATION_CHANGE } from 'react-router-redux';
import { SEARCH_PRODUCER, CHANGE_FIELD} from './constants';
import { selectSearchFields } from './selectors'
import { getRecourceProducers } from 'helpers/service';
import { getProducerSuccess, getProducerFail } from './actions';


export function* searchProducer() {
    const searchDetails = yield select(selectSearchFields());
    
    const result = yield call(getRecourceProducers, searchDetails);    
    if (result.data.errors.length > 0) {
        if (Array.isArray(result.data.errors) && result.data.errors.length) {
            const errors = result.data.errors.map(error => error.message);
            yield put(getProducerFail(errors));
        }
    } else {

        yield put(getProducerSuccess(result));

       
    }
}


export function* getProduerSearchWatcher() {
    while (yield take(SEARCH_PRODUCER)) {
        yield call(searchProducer);
    }
}


export function* producerData() {
    const watcher = yield fork(getProduerSearchWatcher);
    yield take((LOCATION_CHANGE));
    yield cancel(watcher)
}


export default [
    producerData,
];
