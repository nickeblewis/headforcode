import { createSelector } from 'reselect';

export const selectSearchPanelDomain = () => (state) => state.get('producerPage');

export const selectSearchPanel = () => createSelector(
  selectSearchPanelDomain(),
  (substate) => substate.toJS()
);


export const selectFields = () => createSelector(
  selectSearchPanelDomain(),
  (substate) => {
    return substate.getIn(['forms', 'producerSearch', 'fields']).toJS();
  }
);


export const selectBusinessType = () => createSelector(
  selectSearchPanelDomain(),
  (substate) => {
    if(substate.get('businessType') === "recourse"){
      return {
        recourse: true, 
        nonrecourse:false
      }
    } else {
      return {
        recourse: false, 
        nonrecourse:true
      }
    }
  }
)

export const selectBrandColour = () => createSelector(
  selectSearchPanelDomain(),
  (substate) => {
    return substate.getIn('brandColour');
  }
)

export const selectSearchFields = () => createSelector(
  selectSearchPanelDomain(),
  (substate) => {
    return {
      filter: substate.getIn(['forms', 'producerSearch', 'fields',  'search', 'value']),  
    };
  }
)


export const selectSearchResult = () => createSelector(
  selectSearchPanelDomain(),
  (substate) => {
      return {
        data: substate.getIn(['searchResults', 'results'])
      }
  }
)
