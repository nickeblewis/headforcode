import { SEARCH_PRODUCER, CHANGE_FIELD, GET_PRODUCER_SUCCESS, GET_PRODUCER_FAIL, CHANGE_BUSINESSTYPE, CHANGE_LOGO, CHANGE_COLOUR } from './constants';


export function searchProducer() {
    return {
        type: SEARCH_PRODUCER,
    };
}


export function changeBusinessType(data) {
  return {
    type: CHANGE_BUSINESSTYPE,
    data
  };
}

export function changeLogo(data) {
  return {
    type: CHANGE_LOGO,
    data
  };
}

export function changeBrandColour(data) {
  return {
    type: CHANGE_COLOUR,
    data
  };
}



export function changeField(field) {
  return {
    type: CHANGE_FIELD,
    field
  };
}


export function getProducerSuccess(data) {
  return {
    type: GET_PRODUCER_SUCCESS,
    data
  };
}


export function getProducerFail(data) {
  return {
    type: GET_PRODUCER_SUCCESS,
    data
  };
}