import { fromJS } from 'immutable';
import { SEARCH_PRODUCER, CHANGE_FIELD, GET_PRODUCER_SUCCESS, CHANGE_BUSINESSTYPE, CHANGE_LOGO, CHANGE_COLOUR } from './constants';
import { getFields } from './form';


const initialState = fromJS({
  businessType:"nonrecourse",
  brandColour: "",
  forms:{
    producerSearch:{
      fields:getFields()
    }
  },
  searchResults: {
  }
});


function ProducerReducer(state = initialState, action) {
  switch (action.type) {
    case SEARCH_PRODUCER:
      return state
    case CHANGE_FIELD:
        return state
          .setIn(['forms', 'producerSearch', 'fields', action.field.name, 'value'], action.field.value);
    case GET_PRODUCER_SUCCESS:
      return state
          .setIn(['searchResults', 'results'], action.data.data.results);
    case CHANGE_BUSINESSTYPE:
      return state
          .setIn(['businessType'], action.data);
    case CHANGE_LOGO:
      return state
        .setIn(['producerLogo'], action.data);
    case CHANGE_COLOUR:
      return state
        .setIn(['brandColour'], action.data);
    default:
      return state;
  }
}


export default ProducerReducer;
