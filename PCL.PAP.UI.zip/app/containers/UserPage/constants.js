export const SEARCH_USER        = 'app/SearchPanel/SEARCH_USER';
export const CHANGE_FIELD       = 'app/SearchPanel/CHANGE_FIELD';
export const GET_USER_SUCCESS   = 'app/SearchPanel/GET_USER_SUCCESS';
export const GET_USER_FAIL      = 'app/SearchPanel/GET_USER_FAIL';
export const REGISTER_USER      = 'app/SearchPanel/REGISTER_USER';