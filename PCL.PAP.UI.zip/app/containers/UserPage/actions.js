import { SEARCH_USER, CHANGE_FIELD, GET_USER_SUCCESS, GET_USER_FAIL, REGISTER_USER } from './constants';


export function searchUser() {
    return {
        type: SEARCH_USER,
    };
}

export function registerUser(field) {
    return {
        type: REGISTER_USER,
        field
    };
}


export function changeField(field) {
  return {
    type: CHANGE_FIELD,
    field
  };
}


export function getUserSuccess(data) {
  return {
    type: GET_USER_SUCCESS,
    data
  };
}


export function getUserFail(data) {
  return {
    type: GET_USER_SUCCESS,
    data
  };
}