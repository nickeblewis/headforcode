import { createSelector } from 'reselect';

export const selectSearchPanelDomain = () => (state) => state.get('userPage');

export const selectSearchPanel = () => createSelector(
  selectSearchPanelDomainn(),
  (substate) => substate.toJS()
);


export const selectFields = () => createSelector(
  selectSearchPanelDomain(),
  (substate) => {
    return substate.getIn(['forms', 'userSearch', 'fields']).toJS();
  }
);


export const selectSearchFields = () => createSelector(
  selectSearchPanelDomain(),
  (substate) => {
    return {
      filter: substate.getIn(['forms', 'userSearch', 'fields',  'search', 'value']),  
    };
  }
)


export const selectSearchResult = () => createSelector(
  selectSearchPanelDomain(),
  (substate) => {
      return {
        data: substate.getIn(['searchResults', 'results'])
      }
  }
)
