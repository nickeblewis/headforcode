import React from 'react';
import Helmet from 'react-helmet';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import { PageHeader } from 'react-bootstrap';

import { selectFields, selectSearchResult } from './selectors'

import Search from 'components/SearchPanel/Search';
import Branding from 'components/BrandingPanel/';
import { ContactDetails } from 'components/ContactDetailsPanel/ContactDetailsPanel.jsx';
import { PopUserRights } from 'components/PopUserRights/PopUserRightsPanel.jsx';
import { PapUserRights } from 'components/PapUserRights/PapUserRightsPanel.jsx';
import  BussinessTypeSelector  from 'components/BussinessTypeSelectorPanel/';
import AvailableApplicationSelector from 'components/AvailableApplicationSelector/';
import { changeField, searchUser, registerUser } from './actions';
import UserName from './panels/UserName';
import { header, itemRenderer } from './searchFormat';


class UserPage extends React.Component {
  

  constructor(props) {
      super(props);
      this.state = {hidden: false, open:true};
      this.searchInputChanged = this.searchInputChanged.bind(this);
      this.searchSubmitted = this.searchSubmitted.bind(this);
      this.searchResultSelected = this.searchResultSelected.bind(this);
      this.expandSearch = this.expandSearch.bind(this);
  }


  searchInputChanged(event) {
    var field = event;
    this.props.onSearchFieldChanged(field);
  }


  searchSubmitted(event) {
    this.props.onSearchClicked(event);
  }


  searchResultSelected(event) {
    var field = event;
    this.setState({hidden:true});
    this.setState({open:!this.state.open});
    this.props.onRegisterUser(field);
  }


  expandSearch(event) {
    this.setState({open:!this.state.open});
  }


  render() {
    return (
      <div className="producer">
        <Helmet
          title="User Onboarding"
          meta={[{ name: 'description', content: 'PoP Admin Portal' }]}
        />
        <PageHeader>User Onboarding</PageHeader>
        
        <Search
          open={this.state.open} 
          title="Search for Users" 
          onExpand={this.expandSearch}  
          onChange={this.searchInputChanged} 
          onSubmit={this.searchSubmitted} 
          onSelect={this.searchResultSelected} 
          results={this.props.results}
          tableHeader={header}
          itemRenderer={itemRenderer}
        />
        <UserName  hidden={this.state.hidden} />
        <ContactDetails hidden={this.state.hidden} />
        <PopUserRights hidden={this.state.hidden} />
        <PapUserRights hidden={this.state.hidden} />
      </div>
    );      
  }
}


UserPage.propTypes = {
  onSearchFieldChanged: React.PropTypes.func,
  onSearchClicked: React.PropTypes.func
};


function mapDispatchToProps(dispatch) {
  return {
    onSearchFieldChanged: (args) => dispatch(changeField(args)),
    onSearchClicked: (evt) => {
      if (evt !== undefined && evt.preventDefault) evt.preventDefault();
      dispatch(searchUser());
    },
    onRegisterUser: (args) => dispatch(registerUser(args)),
    dispatch,
  };
}


const mapStateToProps = createStructuredSelector({
    fields: selectFields(),
    results: selectSearchResult()
});


export default connect(mapStateToProps, mapDispatchToProps)(UserPage);

