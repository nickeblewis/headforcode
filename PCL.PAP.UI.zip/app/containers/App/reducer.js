import { AUTH_USER_SUCCESS, AUTH_USER, AUTH_USER_FAILURE } from './constants';
import { getMenuProps } from './menu';
import { fromJS } from 'immutable';

// The initial state of the App
const initialState = fromJS({
  loading: false,
  error: false,
  currentUser: false,
  userIsAuthenticated: false,
  sideMenu:getMenuProps()
});

function appReducer(state = initialState, action) {
  switch (action.type) {
    case AUTH_USER:
      return state
        .set('loading', true)
        .set('userIsAuthenticated', false)
        .set('error', false);
    case AUTH_USER_SUCCESS:
      return state
        .set('loading', false)
        .set('userIsAuthenticated', true)
        .set('error', action.error);
    case AUTH_USER_FAILURE:
      return state
        .set('error', true)
        .set('userIsAuthenticated', false)
        .set('loading', false);
    default:
      return state;
  }
}

export default appReducer;
