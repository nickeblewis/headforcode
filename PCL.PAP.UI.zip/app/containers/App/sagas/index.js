import { loadI18nSaga } from './loadI18nSaga';
export { loadI18nSaga };
export default [loadI18nSaga];
