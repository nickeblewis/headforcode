import React from 'react';
import { connect } from 'react-redux';
import Helmet from 'react-helmet';
import { Navbar, Grid, Row, Col, code } from 'react-bootstrap';
import  SideBar from 'components/SideBar/';
import { createStructuredSelector } from 'reselect';
import { selectMenu }  from './selectors';

class App extends React.Component {
  render() {
    return (
      <div>
        <Helmet
          titleTemplate="%s - PoP Admin Portal"
          defaultTitle="PoP Admin Portal"
          meta={[
            { name: 'description', content: 'PoP Admin Portal' },
          ]}
        />

        <Navbar fixedTop>

          <Navbar.Header>
            <Navbar.Brand><a href="#">Admin Portal</a></Navbar.Brand>
            <Navbar.Toggle />
          </Navbar.Header>

          <Navbar.Collapse>
            <Navbar.Text pullRight>Signed in as: <Navbar.Link href="#">Stuart Garner</Navbar.Link></Navbar.Text>
          </Navbar.Collapse>

        </Navbar>

        <div className="wrapper">
          <Grid>     
            <Row className="show-grid">
              <Col xsHidden md={2}></Col>
              <Col xs={12} sm={8} md={7}>
                <div className="content">
                  {this.props.children}
                </div>
              </Col>
              <Col xs={12} sm={4} md={3}><SideBar menu={this.props.sideMenu}/></Col>
            </Row>
          </Grid>   
        </div>
      </div>
      );
  }
}

App.propTypes = {
  children: React.PropTypes.node,
  menu:React.PropTypes.object
};

function mapDispatchToProps(dispatch) {
  return {
  };
}


const mapStateToProps = createStructuredSelector({
    sideMenu: selectMenu()
});



export default connect(mapStateToProps, mapDispatchToProps)(App);
