const menu = {
  menu: {
    showLoginButton:true,
    showLoginOutButton:false,
    showBranchButton:false,
    showBackButton:false,
    showSaveButton:false
  }
};



export const getMenuProps = () => {
  const mappedFields = {};
  Object.entries(menu).forEach(([fieldName, field]) => {
    mappedFields[fieldName] = {
      ...menu
    };
  });
  return mappedFields;
};


