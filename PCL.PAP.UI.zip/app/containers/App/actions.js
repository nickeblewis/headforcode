/*
 * App Actions
 *
 * Actions change things in your application
 * Since this boilerplate uses a uni-directional data flow, specifically redux,
 * we have these actions which are the only way your application interacts with
 * your appliction state. This guarantees that your state is up to date and nobody
 * messes it up weirdly somewhere.
 *
 * To add a new Action:
 * 1) Import your constant
 * 2) Add a function like this:
 *    export function yourAction(var) {
 *        return { type: YOUR_ACTION_CONSTANT, var: var }
 *    }
 */

import {
  AUTH_USER,
  AUTH_USER_SUCCESS,
  AUTH_USER_FAILURE,
  LOAD_I18N,
} from './constants';

import {browserHistory} from 'react-router';

/**
 * Load the user and initiate the user request saga
 *
 * @return (object) An action object with a type of AUTH_USER
 */
export function authUser() {
  return {
    type: AUTH_USER,
  };
}

/**
 * Dispatched when the user data has been loaded by the request saga
 *
 * @return (object) An action object with a type of AUTH_USER_SUCCESS passing the user object
 */
export function authUserSucceeded(data) {
  navigateToDashboard();

  return {
    type: AUTH_USER_SUCCESS,
    data,
  };
}

/**
 * Dispatched when loading the user fails
 *
 * @param (object) The error
 *
 * @returns (object) An action object with a type of AUTH_USER_FAILURE
 */
export function authUserFailed(error) {
  return {
    type: AUTH_USER_FAILURE,
    error,
  };
}

export function loadI18n() {
  return {
    type: LOAD_I18N,
  };
}

export function navigateToLogin() {
  browserHistory.push('/login');
}

export function navigateToDashboard() {
  browserHistory.push('/dashboard');
}


export function navigateToLogout() {
  browserHistory.push('/logout');
}

export function navigateToBranch() {
  browserHistory.push('/branch');
}

export function navigateToProducer() {
  browserHistory.push('/producer');
}

export function navigateToUser() {
  browserHistory.push('/user');
}

export function navigateToPayment() {
  browserHistory.push('/payment-details');
}

export function navigateToBack() {
  //To be done
}
