import { take, call, put, select, fork, cancel } from 'redux-saga/effects';
import { LOCATION_CHANGE } from 'react-router-redux';
import { AUTH_USER } from 'containers/App/constants';
import { authUserSucceeded, authUserFailed } from 'containers/App/actions';// import request from 'utils/request';
import { login } from 'helpers/service';
import { selectLoginFields } from 'containers/LoginPage/selectors';

export function* authUser() {
  const userDetails = yield select(selectLoginFields());
  const result = yield call(login, userDetails);
  console.log(result)
  if (result.data.errors.length > 0) {
    if (Array.isArray(result.data.errors) && result.data.errors.length) {
      const errors = result.data.errors.map(error => error.message);
      yield put(authUserFailed(errors));
    }
  } else {
    yield put(authUserSucceeded(userDetails));
  }
}

export function* getUserWatcher() {
  while (yield take(AUTH_USER)) {
    yield call(authUser);
  }
}

export function* userData() {
  const watcher = yield fork(getUserWatcher);

  yield take(LOCATION_CHANGE);
  yield cancel(watcher);
}

export default [
  userData,
];
