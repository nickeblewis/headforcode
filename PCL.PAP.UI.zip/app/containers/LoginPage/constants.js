/*
 *
 * LoginPage constants
 *
 */

export const CHANGE_FIELD = 'app/LoginPage/CHANGE_FIELD';
export const UPDATE_FIELDS = 'app/LoginPage/UPDATE_FIELDS';
export const VERIFY_LOGIN = 'app/LoginPage/VERIFY_LOGIN';
export const VALIDATE_LOGIN = 'app/LoginPage/VALIDATE_LOGIN';
