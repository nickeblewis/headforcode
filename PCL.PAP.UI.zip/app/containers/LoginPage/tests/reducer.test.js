/* eslint-disable */

import expect from 'expect';
import loginPageReducer from '../reducer';
import { getFields as getLoginFields } from 'containers/LoginPage/form';
import { updateFields, changeField, verifyLogin } from 'containers/LoginPage/actions';
import { fromJS } from 'immutable';

describe('loginPageReducer', () => {
  it('returns the initial state', () => {
    const expected = fromJS({
      forms: {
        login: {
          fields: getLoginFields()
        }
      }
    });

    expect(loginPageReducer(undefined, {}).toJS()).toEqual(expected.toJS());
  });

  it('changes properties of single field using CHANGE_FIELD action', () => {
    const initialState = loginPageReducer(undefined, {});

    const action = changeField({
      field: {
        name: 'userName'
      },
      value: 'newValue'
    });

    const expected = {
        forms: {
            login: {
                fields: {
                    userName: {                       
                        name: 'userName',
                        type: 'text',
                        validators: [
                          'required',
                          'text.max=60',
                          'text.min=60',
                        ],
                        value: 'newValue',
                        hasInteraction: true,
                        errors: []
                    },
                    password: {                       
                        name: 'password',
                        type: 'text',
                        validators: [
                          'required',
                          'text.max=50',
                          'text.min=8'
                        ],
                        value: '',
                        errors: [],
                        hasInteraction: false
                    }
                }
            }
        }
    };

    const returnedValue = loginPageReducer(initialState, action).toJS();

    expect(returnedValue).toEqual(expected);
  });

  it('updates multiple properties of multiple fields with a single UPDATE_FIELDS action', () => {
    const initialState = loginPageReducer(undefined, {});

    const action = updateFields({
      userName: { value: 'newValue' },
      password: { value: 'yetAnotherValue' },
    });

    const expected = {
        forms: {
            login: {
                fields: {
                    userName: {                       
                        name: 'userName',
                        type: 'text',
                        validators: [
                          'required',
                          'text.max=60',
                          'text.min=60',
                        ],
                        value: 'newValue',
                        hasInteraction: true,
                        errors: []
                    },
                    password: {                       
                        name: 'password',
                        type: 'text',
                        validators: [
                          'required',
                          'text.max=50',
                          'text.min=8'
                        ],
                        value: 'yetAnotherValue',
                        errors: [],
                        hasInteraction: true
                    }
                }
            }
        }
    };

    const returnedValue = loginPageReducer(initialState, action).toJS();

    expect(returnedValue).toEqual(expected);
  });

  it('TODO: validators need to be applied . verifies multiple properties of multiple fields with a single VERIFY_LOGIN action', () => {
    const initialState = loginPageReducer(undefined, {});

    const updateFieldsAction = updateFields({
      userName: { value: 'newValue' },
      password: { value: 'yetAnotherValue12345678901234567890' },
    });

    const updatedValue = loginPageReducer(initialState, updateFieldsAction);

    const verifyLoginAction = verifyLogin();

    const expected = {
        forms: {
            login: {
                fields: {
                    userName: {                       
                        name: 'userName',
                        type: 'text',
                        validators: [
                          'required',
                          'text.max=60',
                          'text.min=60',
                        ],
                        value: 'newValue',
                        hasInteraction: true,
                        errors: []
                    },
                    password: {                       
                        name: 'password',
                        type: 'text',
                        validators: [
                          'required',
                          'text.max=50',
                          'text.min=8'
                        ],
                        value: 'yetAnotherValue12345678901234567890',
                        errors: [],
                        hasInteraction: true
                    }
                }
            }
        }
    };

    const returnedValue = loginPageReducer(updatedValue, verifyLoginAction).toJS();
    console.log("RETURNED VALUE FOR LOGIN");
    console.log(JSON.stringify(returnedValue));
    console.log("EXPECTED VALUE FOR LOGIN");
    console.log(JSON.stringify(expected));
    expect(returnedValue).toEqual(expected);
  });
});
