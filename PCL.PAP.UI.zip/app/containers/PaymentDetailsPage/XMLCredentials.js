import React from 'react';
import { connect } from 'react-redux';
import { Panel, Form, FormGroup, FormControl, InputGroup, Glyphicon } from 'react-bootstrap';
import TextInput from 'components/TextInputControl/'


class XMLCredentials extends React.Component {

    constructor(props) {
        super(props);
        this.state = {open: true};
        this.onSelectEvent = this.onSelectEvent.bind(this);
    }


    onSelectEvent(event) {
        this.setState({open:!this.state.open});
    }


    render() { 
        return (
  
                <Panel collapsible expanded={this.state.open} onSelect={this.onSelectEvent} header={<h3>XML Credentials</h3>}> 
                    <Form>
                        <FormGroup>
                            <InputGroup>
                                <InputGroup.Addon><Glyphicon glyph="user" /></InputGroup.Addon>
                                <FormControl type="text" />
                            </InputGroup>
                        </FormGroup>
                        <FormGroup>
                            <InputGroup>
                                <InputGroup.Addon><Glyphicon glyph="phone-alt" /></InputGroup.Addon>
                                <FormControl type="text" />
                            </InputGroup>
                        </FormGroup>
                    </Form>
                </Panel>
      
        )
    }
}


XMLCredentials.propTypes = {
    title: React.PropTypes.string,
    hidden: React.PropTypes.bool
};

XMLCredentials.defaultProps = {
    results:{},
    hidden:true
};


export default XMLCredentials;
