import React from 'react';
import { connect } from 'react-redux';
import { Panel, Form, FormGroup, InputGroup, FormControl, Glyphicon } from 'react-bootstrap';
import TextInput from 'components/TextInputControl/'


class Msc extends React.Component {

    constructor(props) {
        super(props);
        this.state = {open: true};
        this.onSelectEvent = this.onSelectEvent.bind(this);
    }


    onSelectEvent(event) {
        this.setState({open:!this.state.open});
    }


    render() { 
        return (
  
                <Panel collapsible expanded={this.state.open} onSelect={this.onSelectEvent} header={<h3>M S C</h3>}> 
                    <Form>
                        <FormGroup>
                            <InputGroup>
                                <InputGroup.Addon><Glyphicon glyph="gbp" /></InputGroup.Addon>
                                <FormControl type="text" value="20,000" placeholder="Amount"/>
                            </InputGroup>
                        </FormGroup>
                        <FormGroup>
                            <InputGroup>
                                <InputGroup.Addon><Glyphicon glyph="minus-sign" /></InputGroup.Addon>
                                <FormControl type="text" value="1000" placeholder="Minimum"/>
                            </InputGroup>
                        </FormGroup>
                        <FormGroup>
                            <InputGroup>
                                <InputGroup.Addon><Glyphicon glyph="plus-sign" /></InputGroup.Addon>
                                <FormControl type="text" value="45,000" placeholder="Maximum"/>
                            </InputGroup>
                        </FormGroup>
                    </Form>  
                </Panel>
      
        )
    }
}

Msc.propTypes = {
    title: React.PropTypes.string,
    hidden: React.PropTypes.bool
};

Msc.defaultProps = {
    results:{},
    hidden:true
};


export default Msc;
