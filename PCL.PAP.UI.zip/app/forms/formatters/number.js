import { identity } from 'helpers/utils';

const CURRENCY_DEFAULTS = {
  delimeter: ',',
  decimal: '.',
  decimalPlaces: 2
};

const isInteger = num => Number.isInteger(Number(num));

export const number = identity;

number.toDecimal = (num, decimalPlaces = 2) => Number(num).toFixed(decimalPlaces);

number.currency = (
  symbol,
  delimeter = CURRENCY_DEFAULTS.delimeter,
  decimal = CURRENCY_DEFAULTS.decimal,
  decimalPlaces = CURRENCY_DEFAULTS.decimalPlaces
) => (num) =>
  num === '' ? num : (isNaN(Number(num)) ? num : symbol + Number(num).toFixed(decimalPlaces)
    .replace('.', decimal)
    .replace(new RegExp(`(\\d)(?=(\\d{3})+(?:\\${decimal}\\d+)?$)`, 'g'), `$1${delimeter}`));

number.currencyParts = (
  symbol, delimeter, decimal, decimalPlaces
) => (num) => {
  /*
    format the currency as normal, but return it split into two
      - the first half will include the integer formatted with delimiters
      - the second half will include the decimal points and decimal separator
      - either half may contain the currency symbol
  */
  const numArr = number.currency(symbol, delimeter, decimal, decimalPlaces)(num).split(decimal || CURRENCY_DEFAULTS.decimal);
  numArr[1] = `${decimal || CURRENCY_DEFAULTS.decimal}${numArr[1]}`;
  return numArr;
};

number.percentage = (decimalPlaces = 2) => (num) =>
  num === '' ? num : (
    isNaN(Number(num)) ? num : (
      (isInteger(decimalPlaces) ?
        String(Number(num).toFixed(decimalPlaces)) :
        String(num)
      ) + '%'
    )
  );
