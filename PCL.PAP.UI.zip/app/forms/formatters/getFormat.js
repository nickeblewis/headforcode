import { head, last, identity } from 'helpers/utils';
import * as formatters from 'forms/formatters';

export const getFormat = f => {
  try {
    const args = f.indexOf('=') > -1 ? last(f.split('=')).split(',') : [];
    const fn = head(f.split('='));
    const formatter = fn.split('.').reduce((formatterFn, key) => formatterFn[key], formatters);
    return args.length ? formatter(...args) : formatter;
  } catch(e) {
    return identity;
  }
};
