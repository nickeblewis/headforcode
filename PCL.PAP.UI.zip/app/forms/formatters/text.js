import { identity } from 'helpers/utils';

export const text = identity;

text.uppercase = val => val.toUpperCase();
