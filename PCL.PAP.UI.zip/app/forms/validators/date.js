import { i18n } from 'helpers/i18n';
import { compose, filter, head, isUndefined } from 'helpers/utils';

const getStartDate = (field, ctx, parentId) => {
  if (ctx.policyLines.length === 0) return;

  const policyLine = compose(head, filter(a => a.id.value === parentId))(ctx.policyLines);
  if (!policyLine.startDate) return;

  return Number(policyLine.startDate.value);
};

export const date = value => {
  const err = [ { error: i18n('fieldWarnings:dateFormat') } ];

  const val = Number(value);
  if (isNaN(val) || val <= 0) return err;

  const asDate = new Date(val);
  if (Object.prototype.toString.call(asDate) !== '[object Date]') return err;
  return isNaN(Number(asDate.getTime())) ? err : [];
};

date.max = max => value =>
  Number(value) > Number(max) ? [ { error: i18n('fieldWarnings:dateHigh') } ] : [];

date.min = min => value =>
  Number(value) < Number(min) ? [ { error: i18n('fieldWarnings:dateLow') } ] : [];

date.due = (field, ctx) => value => {
  if (ctx.policyLines.length === 0) return [];

  const minDate = Math.min(...ctx.policyLines.map(a => a.startDate.value));

  if (minDate && Number(field.value) !== minDate) {
    if (isUndefined(field.hasInteraction)) field.hasInteraction = true;
    field.requiresUpdate = true;
    field.updateTo = String(minDate);
  }

  return [];
};

date.end = x => [];

date.end.min = (field, ctx, parentId, offset) => value => {
  const dueDate = getStartDate(field, ctx, parentId);
  if (!dueDate) return [];

  const asDate = new Date(Number(dueDate));
  const timeOffset = new Date(Date.UTC(asDate.getFullYear(), asDate.getMonth() + Number(offset), asDate.getDate())).getTime();

  return Number(value) < Number(timeOffset) ? [ { error: i18n('fieldWarnings:dateLow') } ] : [];
};

date.end.max = (field, ctx, parentId, offset) => value => {
  const dueDate = getStartDate(field, ctx, parentId);
  if (!dueDate) return [];

  const asDate = new Date(Number(dueDate));
  const timeOffset = new Date(Date.UTC(asDate.getFullYear(), asDate.getMonth() + Number(offset), asDate.getDate())).getTime();

  return Number(value) > timeOffset ? [ { error: i18n('fieldWarnings:dateHigh') } ] : [];
};

const dateFormatRegex = /^(?:(?:31(\/)(?:0?[13578]|1[02]))\1|(?:(?:29|30)(\/)(?:0?[1,3-9]|1[0-2])\2))(?:(?:1[6-9]|[2-9]\d)?\d{2})$|^(?:29(\/)0?2\3(?:(?:(?:1[6-9]|[2-9]\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00))))$|^(?:0?[1-9]|1\d|2[0-8])(\/)(?:(?:0?[1-9])|(?:1[0-2]))\4(?:(?:1[6-9]|[2-9]\d)?\d{2})$/;

date.formatted = value => dateFormatRegex.test(value);
