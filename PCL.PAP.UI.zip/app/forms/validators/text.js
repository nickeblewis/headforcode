import { i18n } from 'helpers/i18n';

const validCharsNoSpaceRegex = /^[0-9a-z!@#\$%'\(\)\*\+,\-\.\/:;<=>\?\[\\\]\^_`\{\|}~]+$/i;
const validCharsWithSpaceRegex = /^[ 0-9a-z!@#\$%'\(\)\*\+,\-\.\/:;<=>\?\[\\\]\^_`\{\|}~]+$/i;

export const text = {
  max: length => value => value !== '' && value.length > Number(length) ?
    [ { error: i18n('fieldWarnings:valueLong') } ] : [],
  min: length => value => value !== '' && value.length < Number(length) ?
    [ { error: i18n('fieldWarnings:valueShort') } ] : [],
  noDigits: value => /\d/.test(value) ? [ { error: i18n('fieldWarnings:noDigits') } ] : [],
  validChars: allowSpaces => value => {
    const regex = allowSpaces === 'true' ? validCharsWithSpaceRegex : validCharsNoSpaceRegex;
    return !regex.test(value) ? [ { error: i18n('fieldWarnings:invalidChars') } ] : [];
  },
  validPattern: regex => value => {
    const re = new RegExp(regex);
    return !re.exec(value) ? [ { error: i18n('fieldWarnings:invalidChars') } ] : [];
  }
};
