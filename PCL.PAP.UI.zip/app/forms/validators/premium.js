import { compose, map, reduce, isUndefined } from 'helpers/utils';
import { i18n } from 'helpers/i18n';

export const premium = (field, ctx) => value => {
  if (!ctx.policyLines || ctx.policyLines.length === 0) return [];

  const getPolicyLineValues = map(compose(Number, line => line.policyPremium.value));
  const getPolicyLineTotal = reduce((acc, v) => acc += v, 0);
  const policyLineTotal = compose(getPolicyLineTotal, getPolicyLineValues)(ctx.policyLines);
  const totalPremiumValue = Number(value);

  if (totalPremiumValue !== policyLineTotal) {
    // Sorry about the side-effects and all that jazz.
    if (isUndefined(field.hasInteraction)) field.hasInteraction = true;
    field.requiresUpdate = true;
    field.updateTo = String(policyLineTotal);
  }

  return [];
};

premium.outofdate = value => [ { error: i18n('fieldWarnings:outOfDatePremium') } ];
