import { i18n } from 'helpers/i18n';

//"Fix" PCL-1629 (A.K.A Double Dot gate)
const emailRegEx = new RegExp(/^\S+@[^\s\.]+(\.[^\s\.]+)+$/i);

export const email = value =>
  !emailRegEx.test(value) ? [ { error: i18n('fieldWarnings:emailFormat') } ] : [];
