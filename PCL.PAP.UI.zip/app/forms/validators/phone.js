import { i18n } from 'helpers/i18n';
import { uk, ie } from 'forms/utils/phone';

export const phone = {};

phone.uk = value =>
  value === '' || (uk.isValidFormat(value) && uk.validateNSN(uk.extractNSN(value))) ?
    [] : [ { error: i18n('fieldWarnings:phoneFormat') } ];

phone.ie = value =>
  value === '' || ie.isValidFormat(value) ?
    [] : [ { error: i18n('fieldWarnings:phoneFormat') } ];
