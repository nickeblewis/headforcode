import request from 'utils/request';
import defaultConfig from 'config/default.json';
// import defaultConfig from 'config/pcltpopdwebvt01.json';

let config = JSON.parse(JSON.stringify(defaultConfig));

export const setConfig = newConfig => {
  config = JSON.parse(JSON.stringify(newConfig));
};

export const login = (userDetails) => {  
  return request(config.login, { ...userDetails });
};

export const getRecourceProducers = (filters) => {
  return request(config.getRecourceProducers, { ...filters });
};


export const getRecourceBranches = (filters) => {
  return request(config.getRecourceBranches, { ...filters });
};

export const getRegisteredUsers = (filters) => {
  return request(config.getRegisteredUsers, { ...filters });
};
