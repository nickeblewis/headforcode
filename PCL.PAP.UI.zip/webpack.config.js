var path = require('path');
var webpack = require('webpack');

module.exports = {
  context: __dirname + "/app",
  devtool:'eval',// 'cheap-module-source-map',
  entry: './app',
  output: {
    path: __dirname +  '/dist',
    filename: 'bundle.js'
  },
  resolve: {
    root: path.resolve('./app')
  },
  devServer: {
    port:3300,
    historyApiFallback: true
  },
  plugins: [
    //new webpack.optimize.UglifyJsPlugin({minimize: true}), //TODO - add back in for production build environment 
    new webpack.HotModuleReplacementPlugin(),
    /*new webpack.DefinePlugin({
      'process.env': {
        'NODE_ENV': JSON.stringify('production')
      }
    })*/
  ],
  module: {
    loaders: [{
      test: /\.js$/,
      exclude: /(node_modules|bower_components)/,
      loader: 'babel',
      query:{
        presets: ["es2015", "stage-0", "react"]
      }
    }, {
      test: /\.jsx$/,
      exclude: /(node_modules|bower_components)/,
      loader: 'babel',
      query:{
        presets: ["es2015", "stage-0", "react"]
      }
    },{
      test: /\.json$/,
      exclude: /(node_modules|bower_components)/,
      loader: 'json'
    },{
      test: /\.css$/,
      exclude: /(node_modules|bower_components)/,
      loader: 'css'
    }]
  },
  target: 'web'
};
