
module.exports = (app, options) => {
  const isProd = process.env.NODE_ENV === 'production';
  if (isProd) {
    const  productionMiddleware = require('./productionMiddleware');
    productionMiddleware(app, options)
  } else {
    const  webpackDevMiddleware = require('./developmentMiddleware');
    webpackDevMiddleware(app, options)
  }
  return app;
};