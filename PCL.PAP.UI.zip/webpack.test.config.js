var path = require('path');
var webpack = require('webpack');

const config = {
  context:__dirname + "/app",
  devtool:'inline-source-map',
  entry:__dirname + "/app/app.js",
  output: {
    path:__dirname + "/test",
    filename: 'bundle.js'
  },
  resolve: {
    root:path.resolve("./app")
  },
  plugins: [
    new webpack.DefinePlugin({
      TEST: process.env.NODE_ENV === 'test'
    })
  ],
  module: {
    loaders: [{
      test: /\.js$/,
      exclude: /(node_modules|bower_components)/,
      loader: 'babel',
      query:{
        presets: ["es2015", "stage-0", "react"]
      }
    },{
      test: /\.jsx$/,
      exclude: /(node_modules|bower_components)/,
      loader: 'babel',
      query:{
        presets: ["es2015", "stage-0", "react"]
      }
    }]
  }
};



module.exports = config;
